/*
 * my_adc.h
 *
 * Created: 4/18/2022 3:14:13 PM
 *  Author: st991970
 */ 


#ifndef MY_ADC_H_
#define MY_ADC_H_

// #ifdef __cplusplus
// extern "C" {
// #endif
// 
// #include <hal_atomic.h>
// #include <hal_delay.h>
// #include <hal_gpio.h>
// #include <hal_init.h>
// #include <hal_io.h>
// #include <hal_sleep.h>
// 
// #include <hal_adc_sync.h>
// 
// #include <hal_usart_sync.h>
// #ifdef __cplusplus	
// }

void my_adc_init ( void );
void my_adc_configure_callbacks( void );
void my_adc_complete_callback( struct adc_module *const module);
void adc_comp(void);
extern uint16_t adc_result_buffer[ADC_SAMPLES];
extern float adc_avg;

#endif /* MY_ADC_H_ */