/**
 * \file
 *
 * \brief SAM D21 Xplained Pro board initialization
 *
 * Copyright (c) 2013-2018 Microchip Technology Inc. and its subsidiaries.
 *
 * \asf_license_start
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip
 * software and any derivatives exclusively with Microchip products.
 * It is your responsibility to comply with third party license terms applicable
 * to your use of third party software (including open source software) that
 * may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE,
 * INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY,
 * AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE
 * LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL
 * LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE
 * SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE
 * POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT
 * ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY
 * RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
 * THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * \asf_license_stop
 *
 */
/*
 * Support and FAQ: visit <a href="https://www.microchip.com/support/">Microchip Support</a>
 */

#include <compiler.h>
#include <board.h>
#include <conf_board.h>
#include <port.h>
#include "application.h"
#include "comms.h"
#include "my_tcc.h"
#include "my_adc.h"
#include "pid.h"
#include "hb.h"


#if defined(__GNUC__)
void board_init(void) WEAK __attribute__((alias("system_board_init")));
#elif defined(__ICCARM__)
void board_init(void);
#  pragma weak board_init=system_board_init
#endif

static void system_port_init( void )
{
	struct port_config pin_conf;
	port_get_config_defaults(&pin_conf);
	
	/* Set buttons as inputs */
	pin_conf.input_pull = PORT_PIN_PULL_NONE;
	
	pin_conf.direction = PORT_PIN_DIR_OUTPUT;
	port_pin_set_config(LED1_PIN, &pin_conf);
	port_pin_set_output_level(LED1_PIN, LED_INACTIVE);
	
	pin_conf.direction = PORT_PIN_DIR_OUTPUT;
	port_pin_set_config(LED2_PIN, &pin_conf);
	port_pin_set_output_level(LED2_PIN, LED_ACTIVE);
	
	pin_conf.direction = PORT_PIN_DIR_OUTPUT;
	port_pin_set_config(LED3_PIN, &pin_conf);
	port_pin_set_output_level(LED3_PIN, LED_ACTIVE);
	
	pin_conf.direction = PORT_PIN_DIR_OUTPUT;
	port_pin_set_config(LED4_PIN, &pin_conf);
	port_pin_set_output_level(LED4_PIN, LED_ACTIVE);
	
	pin_conf.direction = PORT_PIN_DIR_OUTPUT;
	port_pin_set_config(LED5_PIN, &pin_conf);
	port_pin_set_output_level(LED5_PIN, LED_ACTIVE);
	
	pin_conf.direction = PORT_PIN_DIR_OUTPUT;
	port_pin_set_config(LED6_PIN, &pin_conf);
	port_pin_set_output_level(LED6_PIN, LED_ACTIVE);
	
	pin_conf.direction = PORT_PIN_DIR_OUTPUT;
	port_pin_set_config(EN_MAINS, &pin_conf);
	port_pin_set_output_level(EN_MAINS, false);
		
	pin_conf.direction = PORT_PIN_DIR_OUTPUT;
	port_pin_set_config(HS_SWITCH, &pin_conf);
	port_pin_set_output_level(HS_SWITCH, true);
	
	pin_conf.direction = PORT_PIN_DIR_OUTPUT;
	port_pin_set_config(DATA_0, &pin_conf);
	port_pin_set_output_level(DATA_0, false);
	
	pin_conf.direction = PORT_PIN_DIR_OUTPUT;
	port_pin_set_config(DATA_1, &pin_conf);
	port_pin_set_output_level(DATA_1, false);
	
	pin_conf.direction = PORT_PIN_DIR_OUTPUT;
	port_pin_set_config(DATA_2, &pin_conf);
	port_pin_set_output_level(DATA_2, false);
	
	pin_conf.direction = PORT_PIN_DIR_OUTPUT;
	port_pin_set_config(DATA_3, &pin_conf);
	port_pin_set_output_level(DATA_3, false);
	
	pin_conf.direction = PORT_PIN_DIR_OUTPUT;
	port_pin_set_config(DATA_4, &pin_conf);
	port_pin_set_output_level(DATA_4, false);
	
	pin_conf.direction = PORT_PIN_DIR_OUTPUT;
	port_pin_set_config(DATA_5, &pin_conf);
	port_pin_set_output_level(DATA_5, false);

	pin_conf.direction = PORT_PIN_DIR_OUTPUT;
	port_pin_set_config(EN_DRAIN_BUS, &pin_conf);
	port_pin_set_output_level(EN_DRAIN_BUS, false);
	

	pin_conf.direction  = PORT_PIN_DIR_INPUT;
	pin_conf.input_pull = PORT_PIN_PULL_UP;
	port_pin_set_config(BUTTON_0_PIN, &pin_conf);

	
}
 
void system_board_init(void)
{
	system_port_init();
	//my_tcc_configure(&my_app);
	comms_init();
	hb_init();
	//pid_init(&my_app);
	//my_adc_init();
	
}
