/*
 * serial_interface.h
 *
 * Created: 4/14/2022 3:06:15 PM
 *  Author: st991970
 */ 


#ifndef SERIAL_INTERFACE_H_
#define SERIAL_INTERFACE_H_

	void si_command(volatile uint8_t *uart_buffer);


#endif /* SERIAL_INTERFACE_H_ */