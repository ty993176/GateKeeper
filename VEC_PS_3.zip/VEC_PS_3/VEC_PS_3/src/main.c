/**
 * \file
 *
 * \brief Empty user application template
 *
 */

/**
 * \mainpage User Application template doxygen documentation
 *
 * \par Empty user application template
 *
 * This is a bare minimum user application template.
 *
 * For documentation of the board, go \ref group_common_boards "here" for a link
 * to the board-specific documentation.
 *
 * \par Content
 *
 * -# Include the ASF header files (through asf.h)
 * -# Minimal main function that starts with a call to system_init()
 * -# Basic usage of on-board LED and button
 * -# "Insert application code here" comment
 *
 */

/*
 * Include header files for all drivers that have been imported from
 * Atmel Software Framework (ASF).
 */
/*
 * Support and FAQ: visit <a href="https://www.microchip.com/support/">Microchip Support</a>
 */
#include <asf.h>
#include <delay.h>
#include "application.h"
#include "comms.h"
#include "my_adc.h"
#include "hb.h"
#include "my_tcc.h"
#include "serial_interface.h"
#include "public.h"
#include "system_interrupt.h"
application_t my_app;
volatile unsigned int my_counter = 0;
//volatile unsigned int my_events;
volatile float expected_kv; 
struct adc_module adc_instance;
struct usart_config cb_config;
struct usart_module cb_instance;
struct usart_module usart_command;

//#define MAX_RX_BUFFER_LENGTH   1
#define MAX_RX_BUFFER_LENGTH   1

//void usart_read_callback(struct usart_module *const usart_module);
void ps_control(void);

volatile uint8_t rx_buffer[MAX_RX_BUFFER_LENGTH];
volatile uint8_t my_buffer[32];
volatile uint8_t ps_buffer[32];
volatile uint8_t my_buffer_index = 0;
int i = 0;

void usart_read_callback(struct usart_module *const usart_module) {
// 	for(i = 0; i < MAX_RX_BUFFER_LENGTH; i++){
// 	/*rx_buffer[i] = my_buffer[i];*/
// 	if(rx_buffer[i] == ASCII_LF) {
// 		return;
// 	}else if (rx_buffer[i] == ASCII_FF) {
// 		my_events |= (1<<EF_COMMAND_3);
// 	}else if (rx_buffer[i] == ASCII_CR){
// 		my_events |= (1<<EVENT_USART_RECEIVE);
// 		//printf("\r\n");
// 		i = 0;
// 		return;
// 	}else if ((my_events & (1 << EVENT_USART_RECEIVE)) == 0) {
// 		my_buffer[my_buffer_index++] = rx_buffer[0];
// 		//i++;
// 	}else if(my_buffer_index >= MAX_RX_BUFFER_LENGTH) {
// 		my_buffer_index = 0;
// 	} else {
// 		return;
// 	}
// 	}
	if (rx_buffer[0] == ASCII_LF) {
		//return;
	}else if (rx_buffer[0] == ASCII_CR)
	{
		my_events |= (1<<EVENT_USART_RECEIVE);
		
		return;
	}else if ((my_events & (1 << EVENT_USART_RECEIVE)) == 0) {
 		my_buffer[my_buffer_index++] = rx_buffer[0];
	}else{
		return;
	}
	
}

static void handle_events(void) {
	
	if (my_events & (1<<EVENT_USART_RECEIVE))
	{
		si_command(my_buffer);
		my_events &= ~(1<<EVENT_USART_RECEIVE);
		rx_buffer[0] = 0;
		unsigned char b = 0;
		for(b=0;b<32;b++)
			my_buffer[b] = 0;
			
		my_buffer_index = 0;
		
	}else if (my_events & (1<<EF_COMMAND_2)) {
		my_buffer_index = 0;
		memset_volatile(&rx_buffer,0,sizeof(rx_buffer));
		my_events &= ~(1<<EF_COMMAND_2);
	}
}

void ps_control(void) {
	
	
}

static void clear_command_buffer( void )
{
	//Clear command buffer
	unsigned char c = 0;
	for (c=0;c<32;c++)
	{
		my_buffer[c] = 0;
		ps_buffer[c] = 0;
	}
	my_buffer_index = 0;
	
}

int main (void)
 {
 	system_init();
	//Test
	system_interrupt_enable_global();
	clear_command_buffer();
	//delay_init();
	DRAIN_BUS_DISABLE;	
// 	configure_usart();
// 	configure_usart_callbacks();
	
	/*stdio_serial_init(&usart_command, COMMAND_USART_MODULE, &config_ps_usart);*/
	//port_pin_set_output_level(HS_SWITCH, true);
	//MAINS_ENABLE;
	
	
	my_adc_init();
	my_adc_configure_callbacks();
	
	//adc_read_buffer_job(&adc_instance, adc_result_buffer, ADC_SAMPLES);

		
// 	while(1)
// 	{
// 		handle_events();
//  		usart_read_buffer_job(&usart_command,
//  		(uint8_t *)command_rx_buffer, UART_BUFFER_SIZE);
// 		
// 		 
//  		//port_pin_toggle_output_level(EN_MAINS);
// // 		for(int i = 0; i < 500; i++);
// // 		port_pin_toggle_output_level(LED2_PIN);
// 		
// 	}
	
	/* Setup and config for PWM */
	unsigned int freq;
	freq = 50000;
	
	my_app.period = 1000000*46.6/freq;
	
	my_app.match = 0;

	my_app.dead_high = 0;
	my_app.dead_low = 0;
	
	
	my_tcc_configure(&my_app);
	configure_tcc_callbacks();
	
	/*
	tcc test
	*/
int ii = 0;
int fu = 0;
		//tcc_set_compare_value(&tcc_instance,
		//	(enum tcc_match_capture_channel)
		//	(CH1),
		//	config_tcc.compare.match[CH1]);
		//tcc_set_compare_value(&tcc_instance,0,50000);
		
		
				
	
	my_events = 0;                 
 	//MAINS_ENABLE;
	
// 	while(1);
// 	while(1)
// 	{
// 		
// 		DRAIN_BUS_ENABLE;
// 		delay_cycles_ms(1000);
// 		DRAIN_BUS_DISABLE;
// 		delay_cycles_ms(500);
// 		}

	adc_read_buffer_job(&adc_instance, adc_result_buffer, ADC_SAMPLES);

	while (1) {


		handle_events();
		
 		usart_read_buffer_job(&usart_command,
 		(uint8_t *)rx_buffer, MAX_RX_BUFFER_LENGTH);
		

 		//my_adc_complete_callback(&adc_instance);
// 		stdio_serial_init(&usart_command, COMMAND_USART_MODULE, &config_ps_usart);
// 		for(int i = 0; i<48000000;i++);
// 		printf("BRUH\r\n");
		
 	}	
}
