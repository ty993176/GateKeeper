/*
 * hb.c
 *
 * Created: 4/20/2022 12:53:44 PM
 *  Author: st991970
 */ 


#include <asf.h>
#include "application.h"
#include "hb.h"
#include "my_adc.h"
#include "my_tcc.h"

struct tc_module tc_instance;
//unsigned char rhythm[4] = {15,5,35,5};
unsigned char rhythm[4] = {50,50,50,50};
unsigned char rhythm_index = 0;
unsigned char rhythm_count = 0;
unsigned int prescale = 0;


/* Runs in background. Used to constantly compare ADC values and expected KV values. Increases/Decreases PWM match to acquire desired KV output */
void hb_beat( struct tc_module *const module_inst )
{
	rhythm_count ++;
	
	if (rhythm_count >= rhythm[rhythm_index])
	{
		rhythm_count = 0;
		rhythm_index ++;
		
		if (rhythm_index > 3)
		rhythm_index = 0;
		
		//HB_TOGGLE;
	}
	my_counter ++;
	
	
	prescale++;
	if (prescale > 50)
	{
		
							// Average values of the result buffer.
				
					// ADC avg scaled from 0-3.3 V.
	
		/*  */	
		if(adc_avg > 0) {
			//adc_avg = adc_avg / 8;
			adc_avg = ((adc_avg * 3.3)) / 1024;
		}
		if (expected_kv > adc_avg) {
			if ((adc_avg > (expected_kv - (expected_kv * 1 / 100))) && adc_avg < (expected_kv + (expected_kv * 1 / 100))) {
				return;
			}
				
			if(my_app.match < (my_app.period * 50 / 100)) {
				my_app.match = my_app.match + (my_app.period * 5 / 100);
				if(my_app.match >= (my_app.period * 50 / 100)) {
					my_app.match = (my_app.period * 50 / 100);
				}
				tcc_set_compare_value(&tcc_instance, CH1, my_app.match);
				tcc_set_compare_value(&tcc_instance, CH2, my_app.match);
			}
			
			//my_adc_complete_callback(&adc_instance);
				
// 			}else if(expected_kv == 0) {
// 				my_app.match = 0;
// 				tcc_set_compare_value(&tcc_instance, CH1, my_app.match);
// 				tcc_set_compare_value(&tcc_instance, CH2, my_app.match);
			}else {
			if ((adc_avg > (expected_kv - (expected_kv * 1 / 100))) && adc_avg < (expected_kv + (expected_kv * 1 / 100))) {
				return;
			}
			if(my_app.match > 0) {
				if ((my_app.match > (my_app.period * 5 / 100))) {
					my_app.match = my_app.match - (my_app.period * 5 / 100);
				}else {
					my_app.match = 0;
				}
				tcc_set_compare_value(&tcc_instance, CH1, my_app.match);
				tcc_set_compare_value(&tcc_instance, CH2, my_app.match);
			}
			//my_adc_complete_callback(&adc_instance);
		}
		prescale = 0;
	}
}

void hb_init( void )
{
	struct tc_config config_tc;

	tc_get_config_defaults(&config_tc);

	config_tc.counter_size    = TC_COUNTER_SIZE_16BIT;
	config_tc.wave_generation = TC_WAVE_GENERATION_NORMAL_FREQ;
	config_tc.counter_16_bit.compare_capture_channel[0] = 0xFFFF;
	config_tc.clock_prescaler = TC_CLOCK_PRESCALER_DIV8;
	
	tc_init(&tc_instance, TC3, &config_tc);

	tc_enable(&tc_instance);

	//Enable Callbacks
	
	tc_register_callback(&tc_instance, hb_beat,	TC_CALLBACK_OVERFLOW);
	tc_enable_callback(&tc_instance, TC_CALLBACK_OVERFLOW);
}

