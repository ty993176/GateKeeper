/*
 * my_tcc.h
 *
 * Created: 4/14/2022 5:02:27 PM
 *  Author: st991970
 */ 


#ifndef MY_TCC_H_
#define MY_TCC_H_

	void my_tcc_configure(application_t *a);
	void my_tcc_enable( void );
	void my_tcc_disable( void );
	void tcc_update(application_t *a);
	void configure_tcc_callbacks(void);
	
#endif /* MY_TCC_H_ */