/*
 * application.h
 *
 * Created: 4/13/2022 5:23:07 PM
 *  Author: st991970
 */ 


#ifndef APPLICATION_H_
#define APPLICATION_H_

//Pin Definitions
#define LED1_PIN		PIN_PA13
#define LED2_PIN		PIN_PA12
#define LED3_PIN		PIN_PB15
#define LED4_PIN		PIN_PB14
#define LED5_PIN		PIN_PB13
#define LED6_PIN		PIN_PB12
#define LED_ACTIVE		false
#define LED_INACTIVE	true

//#define HS_SWITCH		PIN_PB31
#define EN_MAINS		PIN_PB03
#define HS_SWITCH		PIN_PA04
#define DATA_0			PIN_PA20
#define DATA_1			PIN_PA21
#define DATA_2			PIN_PA22
#define DATA_3			PIN_PA23
#define DATA_4			PIN_PA24
#define DATA_5			PIN_PA25
#define EN_DRAIN_BUS	PIN_PA06
#define HV_SENSE		PIN_PB09
#define BUS_SENSE		PIN_PA03



//Usart Definitions
#define COMMAND_USART_MODULE		SERCOM5
#define COMMAND_USART_MUX_SETTINGS	USART_RX_1_TX_0_XCK_1
#define COMMAND_USART_PINMUX_PAD0	PINMUX_PB16C_SERCOM5_PAD0
#define COMMAND_USART_PINMUX_PAD1	PINMUX_PB17C_SERCOM5_PAD1
#define COMMAND_USART_PINMUX_PAD2	PINMUX_UNUSED
#define COMMAND_USART_PINMUX_PAD3	PINMUX_UNUSED
#define COMMAND_USART_BAUDRATE		9600
#define UART_BUFFER_SIZE			32
#define KV_BUFFER_SIZE				32
#define HV_SENSE_BUFFER_SIZE		32


//TC Constants
#define PWM_MODULE					TC3


//Port Pin Macros
#define MAINS_ENABLE				port_pin_set_output_level(EN_MAINS,true)
#define MAINS_DISABLE				port_pin_set_output_level(EN_MAINS,false)
#define DRAIN_BUS_ENABLE			MAINS_DISABLE;port_pin_set_output_level(EN_DRAIN_BUS,true)
#define DRAIN_BUS_DISABLE			port_pin_set_output_level(EN_DRAIN_BUS,false)
#define HS_ON						port_pin_set_output_level(HS_SWITCH,true)
#define HS_OFF						port_pin_set_output_level(HS_SWITCH,false)
#define DRAIN_L_ENABLE				port_pin_set_output_level(EN_DRAIN_L,true)
#define DRAIN_L_DISABLE				port_pin_set_output_level(EN_DRAIN_L,false)
#define HB_TOGGLE					port_pin_toggle_output_level(LED1_PIN);
//Help Instruction constants
#define HELP_GENERAL				0
#define HELP_PON					1
#define HELP_POFF					2
#define HELP_PULSE					3
#define HELP_FREQUENCY				4

//ADC Constants
#define ADC_SAMPLES					8
#define ADC_SCALER					(2500/1024)

//ASCII Constants
#define ASCII_CR					13
#define ASCII_LF					10
#define ASCII_FF						12
#define ASCII_BACKSPACE				8			//Check this one
#define ACK							0x06
#define NAK							0x15

//Event Constants
//#define EVENT_USART_RECEIVE			1
#define EVENT_USART_RECEIVE			1
#define EF_COMMAND_1				1
#define EF_COMMAND_2				2
#define EF_COMMAND_3				3

extern struct adc_module adc_instance;

typedef struct application{
	uint32_t		period;
	uint32_t		match;
	unsigned char	dead_high;
	unsigned char	dead_low;
	uint32_t		frequency;
	float			kgain;
	float			ti;
	float			td;
	float			delT;
	float			lowlim;
	float			highlim;
	
}application_t;


extern struct usart_module usart_command;
extern struct usart_module cb_instance;
extern struct usart_config cb_config;
extern struct usart_config config_ps_usart;
extern struct tcc_module tcc_instance;
extern struct tcc_config config_tcc;
extern volatile uint8_t command_tx_buffer[UART_BUFFER_SIZE];
extern volatile uint8_t command_rx_buffer[UART_BUFFER_SIZE];
extern application_t my_app;
extern volatile unsigned int my_counter;
extern volatile float expected_kv;



#endif /* APPLICATION_H_ */