/*
 * hb.h
 *
 * Created: 4/20/2022 12:53:55 PM
 *  Author: st991970
 */ 


#ifndef HB_H_
#define HB_H_

void hb_beat( struct tc_module *const module_inst );
void hb_init( void );




#endif /* HB_H_ */