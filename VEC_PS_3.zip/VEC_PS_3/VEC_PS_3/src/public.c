/*
 * CFile1.c
 *
 * Created: 2/23/2023 10:00:24 AM
 *  Author: ty993176
 */ 
#include <asf.h>
#include "public.h"

void memset_volatile(volatile void *s, char c, size_t n)
{
	volatile char *p = s;
	while (n-- > 0) {
		*p++ = c;
	}
}