/*
 * pid.c
 *
 * Created: 4/18/2022 1:01:40 PM
 *  Author: st991970
 */ 

#include <asf.h>
#include <string.h>
#include "application.h"
#include "pid.h"
#include "my_adc.h"

my_pid_params_t pid_param;
my_pid_state_t	pid_state;
struct tc_config pid_tc;
struct tc_module pid_instance;
float pid_out = 0;

void pid_init( application_t *a )
{
	
	a->kgain = 1;
	a->ti = 100;
	a->td = 100;
	a->delT = 1;
	
	pid_param.Kgain = my_app.kgain;
	pid_param.Ti = my_app.ti;
	pid_param.Td = my_app.td;
	pid_param.delT = my_app.delT;
	pid_param.highlim = 3276; //5% of actual maximum
	pid_param.lowlim = 0;
	pid_param.setpt = 512;
	
	memset(&adc_result_buffer,0,sizeof(adc_result_buffer));
	
	pid_timer_init();
	
}

inline float pid_avg_fb( void )
{
	unsigned int i;
	float f = 0;
	for (i=0;i<ADC_SAMPLES;i++)
	{
		f += adc_result_buffer[i];
	}
	
	f /= ADC_SAMPLES;
	return f;
}

void pid_cycle( void )
{
	float cycle_change = 0;
	float pid_out_temp = 0;
	float seterr = pid_avg_fb() - pid_param.setpt;
	//Calculate proportional response
	pid_out_temp += pid_state.integral * pid_param.delT / pid_param.Ti;
	pid_state.integral += seterr;
	cycle_change = seterr - pid_state.deriv;
	pid_out_temp += cycle_change * pid_param.Td / pid_param.delT;
	pid_state.deriv = seterr;
	pid_out_temp *= -pid_param.Kgain;
	
	if (pid_out_temp > pid_param.highlim){
		pid_out_temp = pid_param.highlim;
	}else if(pid_out_temp < pid_param.lowlim){
		pid_out_temp = pid_param.lowlim;
	}
	
	pid_out = pid_out_temp;
}

void pid_overflow( struct tc_module *const module_inst )
{
	pid_tc.counter_16_bit.compare_capture_channel[0] = (unsigned int)pid_out;
	//pid_tc.counter_16_bit.compare_capture_channel[0] = 5;
}

void pid_timer_init( void )
{
	

	tc_get_config_defaults(&pid_tc);

	pid_tc.counter_size    = TC_COUNTER_SIZE_16BIT;
	pid_tc.wave_generation = TC_WAVE_GENERATION_NORMAL_FREQ;
	pid_tc.counter_16_bit.compare_capture_channel[0] = 0xFFFF;
	pid_tc.clock_prescaler = TC_CLOCK_PRESCALER_DIV8;
	
	tc_init(&pid_instance, TC4, &pid_tc);

	tc_enable(&pid_instance);

	//Enable Callbacks
	
	tc_register_callback(&pid_instance, pid_overflow, TC_CALLBACK_OVERFLOW);
	tc_enable_callback(&pid_instance, TC_CALLBACK_OVERFLOW);
}
