/*
 * comms.h
 *
 * Created: 4/13/2022 6:30:59 PM
 *  Author: st991970
 */ 


#ifndef COMMS_H_
#define COMMS_H_

void comms_init( void );
void configure_usart(void);
void configure_usart_callbacks(void);
void usart_read_callback(struct usart_module *const usart_module);

volatile unsigned int my_events;
extern volatile uint8_t command_buffer[UART_BUFFER_SIZE];
//extern struct usart_config config_ps_usart;



#endif /* COMMS_H_ */