/*
 * comms.c
 *
 * Created: 4/13/2022 6:30:50 PM
 *  Author: st991970
 */ 

#include <asf.h>
#include <stdio.h>
#include "application.h"
#include "comms.h"

void usart_ps_read_callback(struct usart_module *const usart_module);
void usart_ps_write_callback(struct usart_module *const usart_module);

//volatile unsigned int my_events;
volatile uint8_t command_tx_buffer[UART_BUFFER_SIZE];
volatile uint8_t command_rx_buffer[UART_BUFFER_SIZE];

struct usart_config config_ps_usart;
struct usart_module usart_command;

void usart_ps_read_callback(struct usart_module *const usart_module)
{
	port_pin_toggle_output_level(LED1_PIN);
	
}

void usart_ps_write_callback(struct usart_module *const usart_module)
{
	port_pin_toggle_output_level(LED2_PIN);
	
}

void configure_usart(void)
{
	
	usart_get_config_defaults(&config_ps_usart);
	
	config_ps_usart.baudrate    = COMMAND_USART_BAUDRATE;
	config_ps_usart.mux_setting = COMMAND_USART_MUX_SETTINGS;
	config_ps_usart.pinmux_pad0 = COMMAND_USART_PINMUX_PAD0;
	config_ps_usart.pinmux_pad1 = COMMAND_USART_PINMUX_PAD1;
	config_ps_usart.pinmux_pad2 = COMMAND_USART_PINMUX_PAD2;
	config_ps_usart.pinmux_pad3 = COMMAND_USART_PINMUX_PAD3;
	while (usart_init(&usart_command,
	COMMAND_USART_MODULE, &config_ps_usart) != STATUS_OK) {
	}
	usart_enable(&usart_command);
	stdio_serial_init(&usart_command,COMMAND_USART_MODULE, &config_ps_usart);
	
}

void configure_usart_callbacks(void)
{	
	usart_register_callback(&usart_command, usart_ps_write_callback, USART_CALLBACK_BUFFER_TRANSMITTED);
	usart_register_callback(&usart_command, usart_read_callback, USART_CALLBACK_BUFFER_RECEIVED);
	
	usart_enable_callback(&usart_command, USART_CALLBACK_BUFFER_TRANSMITTED);
	usart_enable_callback(&usart_command, USART_CALLBACK_BUFFER_RECEIVED);
}


void comms_init( void )
{
	configure_usart();
	configure_usart_callbacks();
// 	usart_ps_read_callback(&usart_command);
// 	usart_ps_write_callback(&usart_command);
}