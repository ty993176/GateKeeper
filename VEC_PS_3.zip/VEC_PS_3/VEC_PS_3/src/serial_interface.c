/*
 * serial_interface.c
 *
 * Created: 4/14/2022 3:06:26 PM
 *  Author: st991970
 */ 


#include <asf.h>
#include <stdio.h>
#include <string.h>
#include "application.h"
#include "serial_interface.h"
#include "my_tcc.h"
#include "public.h"
#include "my_adc.h"

struct tcc_module tcc_instance;

static void print_help(unsigned char command)
{
	if (command == HELP_GENERAL){
		printf("For more information on a specific command, type HELP command-name\r\n\r\n");
		printf("DEAD		Inserts dead time in the pump.\r\n");
		printf("FREQUENCY	Stop the stack pump, then sets the output oscillator\r\n");
		printf("PON			Enables the mains relay.\r\n");
		printf("POFF		Disables the mains relay.\r\n");
		printf("PULSE		Pulses the high side switch between 1ms and 100ms.\r\n");
		printf("RESET		Performs a soft reset of the control card.\r\n");
		printf("START		Starts the stack pump.\r\n");
		printf("STOP		Stops the stack pump.\r\n");
	}else if (command == HELP_PON){
		printf("Enable the mains relay.  There are no parameters to this function.\r\n");
	}else if (command == HELP_POFF){
		printf("Disables the mains relay.  There are no parameters to this function.\r\n");
	}else if (command == HELP_PULSE){
		printf("Pulses the high side switch between 1ms and 100ms.\r\n");
		printf("PULSE [On Time mS]\r\n");
	}else if (command == HELP_FREQUENCY){
		printf("Stops the stack pump, then sets the output oscillator.\r\n");
		printf("Finally restarts the stack pump at the new frequency.\r\n\r\n");
		printf("FREQUENCY [Hz]\r\n");		
	}
}

void si_command(volatile uint8_t *uart_buffer)
{
	
	/*uint16_t expected_kv;*/
	char my_buffers[UART_BUFFER_SIZE];
	unsigned char c = 0;
	char *tokenA = 0;
	char *tokenB = 0;
	char *tokenC = 0;
	char *tokenD = 0;
	char *tokenE = 0;
		
	const char s[2] = " ";

	//comm.receive_inhibit = 1;

	//remove volatile qualifier
	for (c=0;c<UART_BUFFER_SIZE;c++)
	{
		if(uart_buffer[0] == 0 && uart_buffer[1] != 0) {
			my_buffers[c] = uart_buffer[c + 1];
		}else{
			my_buffers[c] = uart_buffer[c];
		}
	}

	//Get Tokens
	tokenA = strtok(my_buffers,s);
	if (tokenA != NULL)
	{
		tokenB = strtok(NULL,s);
		if (tokenB != NULL)
		{
			tokenC = strtok(NULL,s);
			if (tokenC !=NULL)
			{
				tokenD = strtok(NULL,s);
				if (tokenD !=NULL)
				{
					tokenE = strtok(NULL,s);
				}
			}
		}
	}
		
	//Start Testing tokens
	if (strcasecmp(tokenA,"MAINS") == 0)
	{
		int M = atoi(tokenB);
		if(M == 1) {
			MAINS_ENABLE;
			stdio_serial_init(&usart_command, COMMAND_USART_MODULE, &config_ps_usart);
			printf("PS MAINS RON\r\n");
			
			
		}else if(M == 0) {
			MAINS_DISABLE;
			stdio_serial_init(&usart_command, COMMAND_USART_MODULE, &config_ps_usart);
			printf("PS MAINS ROFF\r\n");
		}

	}else if(strcasecmp(tokenA, "SET") == 0) {
			expected_kv = atoi(tokenB);
			//expected_kv = 5000;
			expected_kv = expected_kv * 3.3 / 2500;
// 			if (expected_kv == 0) {
// 				my_app.match = 0;
// 			}
			//expected_kv = 1.22 + expected_kv;
			//uint16_t adc_avg;
// 			adc_instance.hw->CTRLA.bit.ENABLE = 0;
// 			adc_instance.hw->CTRLA.bit.SWRST = 1;
			my_adc_complete_callback(&adc_instance);
			//adc_avg = adc_avg * 2500 / 3.3;
			stdio_serial_init(&usart_command, COMMAND_USART_MODULE, &config_ps_usart);
			printf("KV %u\r\n",  1);
			
	}else if(strcasecmp(tokenA, "POFF") == 0){
		MAINS_DISABLE;
	}else if (strcasecmp(tokenA, "PULSE") == 0){
		unsigned int pulse_delay = 0;
		if (tokenB != NULL)
		{
			pulse_delay = atoi(tokenB);
			if ((pulse_delay>0) && (pulse_delay<100))
			{
				//Pulse duration is in the acceptable range
				HS_ON;
				delay_ms(pulse_delay);
				HS_OFF;
			}else{ 
				printf("Please select a pulse duration between 1ms and 100ms.\r\n");
			}
		}
	}else if (strcasecmp(tokenA, "HBUS?") == 0) {
		my_adc_complete_callback(&adc_instance);
		float KV_RES = 0;
		uint16_t kvres;
		KV_RES = adc_avg / 8;
		KV_RES = KV_RES * 2500 / 1024;
		kvres = KV_RES * 1;
		stdio_serial_init(&usart_command, COMMAND_USART_MODULE, &config_ps_usart);
		printf("KV READ %u\r\n", kvres);
	}else if (strcasecmp(tokenA, "PUMP") == 0){
		if (strcasecmp(tokenB, "ON") == 0){
			my_tcc_configure(&my_app);
			
		}else if (strcasecmp(tokenB, "OFF") == 0){
			my_tcc_disable();
		}else if (strcasecmp(tokenB, "FREQUENCY") == 0){
			unsigned int frequency = 0;
			if (tokenC != NULL)
			{
				frequency = atoi(tokenC);
			}else{
				printf("Please select a frequency between 80kHz, and 120kHz.\r\n");
			}
		}
	}else if(strcasecmp(tokenA, "DUTY") == 0) {
		int D = 0;
		uint8_t DS = 0;
		D = atoi(tokenB);
		//my_app.match = my_app.period * D / 100;
		//tcc_set_compare_value(&tcc_instance, 0, my_app.match);
		my_app.match = my_app.period * D / 100;
		//tcc_set_compare_value(&tcc_instance,
					//(enum tcc_match_capture_channel)(CH1), my_app.match);
		tcc_set_compare_value(&tcc_instance, 0, 932*(100-D)/100);
		tcc_set_compare_value(&tcc_instance, 1, 932*(D)/100);
		
		stdio_serial_init(&usart_command, COMMAND_USART_MODULE, &config_ps_usart);
		DS = D * 1;
		printf("DSET %u\r\n", DS);
	
	}else if (strcasecmp(tokenA, "HELP") == 0){
		if (strcasecmp(tokenB, "PON") == 0){
			print_help(HELP_PON);
		}else if(strcasecmp(tokenB, "POFF") == 0){
			print_help(HELP_POFF);
		}else if (strcasecmp(tokenB, "PULSE")){
			print_help(HELP_PULSE);
		}else{
			print_help(HELP_GENERAL);
		}
	}else if (strcasecmp(tokenA, "TEST") == 0) {
		//my_app.period = 1000000*46.6/50000;
		my_app.match = my_app.period * 25 / 100;
		tcc_set_compare_value(&tcc_instance, 0, my_app.match);
		
		stdio_serial_init(&usart_command, COMMAND_USART_MODULE, &config_ps_usart);
		printf("BRUH\r\n");
		
	}
	memset_volatile(&uart_buffer,0,sizeof(uart_buffer));
	//printf("BRUH\r\n");
	
}
