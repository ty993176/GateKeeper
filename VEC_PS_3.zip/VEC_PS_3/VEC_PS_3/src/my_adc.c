/*
 * my_adc.c
 *
 * Created: 4/18/2022 3:14:02 PM
 *  Author: st991970
 */ 

#include <asf.h>
#include "application.h"
#include "my_adc.h"
#include "my_tcc.h"

uint16_t adc_result_buffer[ADC_SAMPLES];
float adc_avg;
struct adc_module adc_instance;
struct tcc_module tcc_instance;
volatile bool adc_read_done = false;
application_t my_app;
int flgres;
uint16_t adc_test = 0;

void my_adc_init( void )
{
	struct adc_config config_adc;
	adc_get_config_defaults(&config_adc);
	//config_adc.clock_source = GCLK_GENERATOR_1;
	config_adc.clock_prescaler = ADC_CLOCK_PRESCALER_DIV8;
	config_adc.reference = ADC_REFERENCE_INTVCC1;
	config_adc.positive_input = ADC_POSITIVE_INPUT_PIN3; /*|
								ADC_INPUTCTRL_MUXNEG_GND |
								ADC_INPUTCTRL_GAIN_DIV2;*/
	config_adc.resolution = ADC_RESOLUTION_10BIT;
	//config_adc.gain_factor = ADC_GAIN_FACTOR_2X;
	config_adc.accumulate_samples = ADC_ACCUMULATE_SAMPLES_8;
	//config_adc.divide_result = ADC_DIVIDE_RESULT_8;
	
	adc_init(&adc_instance, ADC, &config_adc);
	adc_enable(&adc_instance);
	//adc_enable_events(&adc_instance);
	adc_instance.hw->CTRLB.bit.RESSEL = 2;
	adc_instance.hw->CTRLA.bit.ENABLE = 1;
	
}

void my_adc_configure_callbacks( void )

{
	adc_register_callback(&adc_instance, my_adc_complete_callback, ADC_CALLBACK_READ_BUFFER);
	adc_enable_callback(&adc_instance, ADC_CALLBACK_READ_BUFFER); 
}


void my_adc_complete_callback(struct adc_module *const module) 
{
	/*adc_instance.hw->CTRLA.bit.ENABLE = 0;*/
//	adc_instance.hw->INTFLAG.bit.RESRDY = 0;
 	
	adc_instance.hw->CTRLA.bit.SWRST = 0;
	adc_instance.hw->CTRLA.bit.ENABLE = 1;
	
	adc_instance.hw->SWTRIG.bit.START = 1;
 	int i = 0;
 	
//  	adc_instance.hw->AVGCTRL.bit.SAMPLENUM = ADC_AVGCTRL_SAMPLENUM_8;
//  	adc_instance.hw->AVGCTRL.bit.ADJRES = 0x3;
	
	//flgres = adc_get_status(&adc_instance);
 	if(!(adc_instance.hw->INTFLAG.bit.RESRDY)) {
	//if(!(flgres)) {	
		return;
	}
	//adc_start_conversion(&adc_instance);
	adc_avg = 0;
	adc_read_buffer_job(&adc_instance, adc_result_buffer, ADC_SAMPLES);
	
	
	


			for(i = 0; i < 8; i++) {
				
				adc_avg = adc_avg + adc_result_buffer[i];
			}
							//Time delay to allow result buffer to fill.
		
	//adc_test = adc_read(&adc_instance, &adc_test);
	//adc_avg = adc_avg + adc_test;
 	adc_avg = adc_avg / 8;					// Average values of the result buffer.
// 	
 	adc_avg = ((adc_avg * 3.3)) / 1024;
	adc_read_done = true;
	
	//adc_flush(&adc_instance);
	//adc_disable(&adc_instance);
	adc_instance.hw->CTRLA.bit.ENABLE = 0;
	//adc_instance.hw->CTRLA.bit.SWRST = 1;
	//adc_instance.hw->RESULT.reg = adc_avg;
// 	for(int j = 0; j < 8; j++) {
// 		adc_result_buffer[j] = 0;
// 	}	
}


void adc_comp(void) {
	//while(adc_read_done == false) {
	my_adc_complete_callback(&adc_instance);
	
// 	while (!(adc_instance.hw->INTFLAG.bit.RESRDY)) {}
// 	adc_avg = adc_instance.hw->RESULT.reg;		// Store 8 values into the result buffer.
// 	
// 	adc_avg = adc_avg * 2500 / 1024;
// 	adc_read_done = true;

	
	//my_adc_complete_callback(&adc_instance);

// 	if (expected_kv > adc_avg) {
// 		if ((adc_avg > (expected_kv - (expected_kv * 0.25 / 100))) && adc_avg < (expected_kv + (expected_kv * .25 / 100))) {
// 			return;
// 		}
// 		
// 			//if(my_app.match <= (my_app.period * 50 / 100)) {
// 			my_app.match = my_app.match + (my_app.period * 0.25 / 100);
// 				//tcc_set_compare_value(&tcc_instance, 0, my_app.match);
// // 				tcc_set_compare_value(&tcc_instance,
// // 				(enum tcc_match_capture_channel)(CH1), my_app.match);
// // 			tcc_set_compare_value(&tcc_instance, 0, 1024*(100-my_app.match)/100);
// // 			tcc_set_compare_value(&tcc_instance, 1, 1024*my_app.match/100);
// 			tcc_set_compare_value(&tcc_instance, CH1, 932-my_app.match);
// 			tcc_set_compare_value(&tcc_instance, CH2, my_app.match);
// 		//}
// 			for(i = 0; i < 20000; i++);
// 			my_adc_complete_callback(&adc_instance);
// 		
// 	}else if(expected_kv < adc_avg) {
// 		if ((adc_avg > (expected_kv - (expected_kv * 0.25 / 100))) && adc_avg < (expected_kv + (expected_kv * .25 / 100))) {
// 			return;
// 		}
// 			
// 			my_app.match = my_app.match - (my_app.period * 0.25 / 100);
// 			//tcc_set_compare_value(&tcc_instance, 0, my_app.match);
// // 			tcc_set_compare_value(&tcc_instance,
// // 			(enum tcc_match_capture_channel)(CH1), my_app.match);
// // 			tcc_set_compare_value(&tcc_instance, 0, 1024*(100-my_app.match)/100);
// // 			tcc_set_compare_value(&tcc_instance, 1, 1024*my_app.match/100);
// 			tcc_set_compare_value(&tcc_instance, CH1, 932-my_app.match);
// 			tcc_set_compare_value(&tcc_instance, CH2, my_app.match);
// 						
// 			for(i = 0; i < 50000; i++);
// 			my_adc_complete_callback(&adc_instance);
// 		}
// 	}	
// 	
}