/*
 * pid.h
 *
 * Created: 4/18/2022 1:01:54 PM
 *  Author: st991970
 */ 


#ifndef PID_H_
#define PID_H_


typedef struct my_pid_params
{
	float Kgain;	//Loop Gain
	float Ti;		//Integrator Time Constant
	float Td;		//Differentiator time constant
	float delT;		//Update time interval
	
	float setpt;	//Set Point
	float lowlim;	//Low Limit
	float highlim;	//High Limit
}my_pid_params_t;

typedef struct my_pid_state
{
	float integral;	//Summation of set point errors
	float deriv;	//Previous set point error
}my_pid_state_t;

void pid_init( application_t *a );
void pid_cycle( void );
void pid_overflow( struct tc_module *const module_inst );
void pid_timer_init( void );



#endif /* PID_H_ */