/*
 * PUBLIC.h
 *
 * Created: 2/23/2023 9:58:57 AM
 *  Author: ty993176
 */ 


#ifndef PUBLIC_H_
#define PUBLIC_H_

void memset_volatile(volatile void *s, char c, size_t n);



#endif /* PUBLIC_H_ */