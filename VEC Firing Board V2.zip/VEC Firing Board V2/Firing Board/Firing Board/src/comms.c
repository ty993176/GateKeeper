/*
 * comms.c
 *
 * Created: 4/13/2022 6:30:50 PM
 *  Author: st991970
 */ 

#include <asf.h>
#include <stdio.h>
#include "application.h"
#include "comms.h"
#include "serial_interface.h"
#include "system_interrupt.h"


void usart_f2_read_callback(struct usart_module *const usart_module);
void usart_f2_write_callback(struct usart_module *const usart_module);
void usart_f_write_callback(struct usart_module *const usart_module);

/*volatile uint16_t event_flags;*/
volatile uint32_t command_tx_buffer[UART_BUFFER_SIZE];
volatile uint32_t command_rx_buffer[UART_BUFFER_SIZE];

struct usart_config config_f_usart;
struct usart_config config_f2_usart;
struct usart_module usart_command;
struct usart_module usart_command1;

volatile uint8_t f2_buffer[UART_BUFFER_SIZE];
volatile uint8_t f2_rx_buffer[1];
volatile uint8_t f2_buffer_index = 0;


void usart_f2_read_callback(struct usart_module *const usart_module)
{
	if (f2_rx_buffer[0] == ASCII_LF) {
		//return;
	}else if (f2_rx_buffer[0] == ASCII_CR)
	{
		event_flags |= (1<<EVENT_USART_RECEIVE);
		
		return;
		}else if ((event_flags & (1 << EVENT_USART_RECEIVE)) == 0) {
		f2_buffer[f2_buffer_index++] = f2_rx_buffer[0];
		}else{
		return;
	}
	
}

void usart_f2_write_callback(struct usart_module *const usart_module)
{
	port_pin_toggle_output_level(LED2_PIN);
	
}

void usart_f_write_callback(struct usart_module *const usart_module)
{
	port_pin_toggle_output_level(LED2_PIN);
	
}

void configure_usart(void)
{
	usart_get_config_defaults(&config_f_usart);
	
	config_f_usart.baudrate = COMMAND_USART_BAUDRATE;
	config_f_usart.mux_setting  = COMMAND_USART_MUX_SETTINGS1;
	config_f_usart.pinmux_pad0 = COMMAND_USART_PINMUX_PAD0_1;
	config_f_usart.pinmux_pad1 = COMMAND_USART_PINMUX_PAD1_1;
	config_f_usart.pinmux_pad2 = COMMAND_USART_PINMUX_PAD2_1;
	config_f_usart.pinmux_pad3 = COMMAND_USART_PINMUX_PAD3_1;
	while (usart_init(&usart_command,
	COMMAND_USART_MODULE1, &config_f_usart) != STATUS_OK) {
	}
	usart_enable(&usart_command);
	stdio_serial_init(&usart_command,COMMAND_USART_MODULE1, &config_f_usart); 	
	
	config_f2_usart.baudrate = COMMAND_USART_BAUDRATE;
	config_f2_usart.mux_setting  = COMMAND_USART_MUX_SETTINGS1;
	config_f2_usart.pinmux_pad0 = COMMAND_USART_PINMUX_PAD0;
	config_f2_usart.pinmux_pad1 = COMMAND_USART_PINMUX_PAD1;
	config_f2_usart.pinmux_pad2 = COMMAND_USART_PINMUX_PAD2;
	config_f2_usart.pinmux_pad3 = COMMAND_USART_PINMUX_PAD3;
	while (usart_init(&usart_command1,
	COMMAND_USART_MODULE2, &config_f2_usart) != STATUS_OK) {
	}
	usart_enable(&usart_command1);
	//stdio_serial_init(&usart_command1,COMMAND_USART_MODULE2, &config_f2_usart);
}

void configure_usart_callbacks(void)
{	
	usart_register_callback(&usart_command, usart_f_write_callback, USART_CALLBACK_BUFFER_TRANSMITTED);
	usart_register_callback(&usart_command, usart_read_callback, USART_CALLBACK_BUFFER_RECEIVED);
	usart_enable_callback(&usart_command, USART_CALLBACK_BUFFER_TRANSMITTED);
	usart_enable_callback(&usart_command, USART_CALLBACK_BUFFER_RECEIVED);
	
	usart_register_callback(&usart_command1, usart_f2_write_callback, USART_CALLBACK_BUFFER_TRANSMITTED);
	usart_register_callback(&usart_command1, usart_f2_read_callback, USART_CALLBACK_BUFFER_RECEIVED);
	usart_enable_callback(&usart_command1, USART_CALLBACK_BUFFER_TRANSMITTED);
	usart_enable_callback(&usart_command1, USART_CALLBACK_BUFFER_RECEIVED);
}


void comms_init( void )
{
	configure_usart();
	configure_usart_callbacks();
	
}