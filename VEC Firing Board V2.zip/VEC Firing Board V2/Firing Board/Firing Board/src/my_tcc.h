/*
 * my_tcc.h
 *
 * Created: 8/9/2023 10:04:59 AM
 *  Author: ty993176
 */ 


#ifndef MY_TCC_H_
#define MY_TCC_H_

void my_tcc_configure(application_t *a);
void my_tcc_enable( void );
void my_tcc_disable( void );
void tcc_update(application_t *a);
void configure_tcc_callbacks(void);



#endif /* MY_TCC_H_ */