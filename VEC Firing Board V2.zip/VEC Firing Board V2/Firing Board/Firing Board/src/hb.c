/*
 * CFile1.c
 *
 * Created: 8/9/2023 9:51:39 AM
 *  Author: ty993176
 */ 

#include <asf.h>
#include "application.h"
#include "hb.h"
#include "my_tcc.h"
#include "firing_board.h"
#include <stdio.h>
#include <delay.h>
#include <stdlib.h>
#include <inttypes.h>
#include <unistd.h>
#include <time.h>




//pulses_t my_pulse;


struct tc_module tc_instance;
unsigned char rhythm[4] = {50,50,50,50};
unsigned char rhythm_index = 0;
unsigned char rhythm_count = 0;

int wait_loop0 = 10000;
int wait_loop1 = 6000;

unsigned int psc1 = 0;
unsigned int psc2 = 0;
int set_tc = 0;

/* Timer for executing pulsing as set by user. Interrupt driven. */
void hb_beat( struct tc_module *const module_inst )
{
	//if ((my_pulse.my_cycles_count <= (my_pulse.cycles * 48000000 / 65536)) || (my_pulse.cycles == 0))
	//if(((my_pulse.channelnxt - 8*boardnum) <=  8) && ((my_pulse.channelnxt - 8*boardnum) > 0)) {
		if ((my_pulse.my_pulsecount < my_pulse.pulsecount))
		{
			//psc2++;
			if(my_pulse.channel > 0) {
				psc1++;
				
					if(my_pulse.output_state == 1)	{		// On Time counter set up/compare
						if(set_tc == 1) {
							tc_set_compare_value(&tc_instance, TC_COMPARE_CAPTURE_CHANNEL_0, (my_pulse.time_on * 48000000 / 65536));
							port_pin_set_output_level(my_pulse.channel, my_pulse.output_state);
							set_tc = 0;

						}
					
						if(psc1 >= (uint16_t)(my_pulse.time_on * 48000000 / 65536)) {		// Setup for Off time counter
							my_pulse.output_state = 0;
							set_tc = 1;
							psc1 = 0;
						}
					
					}
					if (my_pulse.output_state == 0) {		// Off time counter compare
						if(set_tc == 1) { 
							tc_set_compare_value(&tc_instance, TC_COMPARE_CAPTURE_CHANNEL_0, (my_pulse.time_off * 48000000 / 65536));
							port_pin_set_output_level(my_pulse.channel, my_pulse.output_state);
							set_tc = 0;
						}
					
						if(psc1 >= (uint32_t)(my_pulse.time_off * 48000000 / 65536)) {
							my_pulse.output_state = 1;
							set_tc = 1;
							psc1 = 0;
							my_pulse.my_pulsecount++;
							if(my_pulse.my_pulsecount == my_pulse.pulsecount){
								my_pulse.pulsedone = 1;
							}
						}
					
					}else {
						//reset
					}
			
			}
	
		}else {
			psc2++;
			port_pin_set_output_level(my_pulse.channel, 0);
			if(my_pulse.channelnxt == my_pulse.channelend) {
				tc_set_compare_value(&tc_instance, TC_COMPARE_CAPTURE_CHANNEL_0, (my_pulse.pausedur * 48000000 / 65536));	
			}else {
				//my_pulse.pulsedone = 0;
				my_pulse.channelnxt++;
				ps_pulse(&my_pulse, boardnum);
				my_pulse.my_pulsecount = 0;
				psc2 = 0;
			}
			if(psc2 >= (uint32_t)(my_pulse.pausedur * 48000000 / 65536)){
				tc_disable(&tc_instance);
				tc_disable_callback(&tc_instance, TC_COMPARE_CAPTURE_CHANNEL_0);
				stdio_serial_init(&usart_command, COMMAND_USART_MODULE1, &config_f_usart);
				printf("PULSING DONE\r\n");
			}
		
		}
	//}
}

/* Initialization for timer and above code */ 
void hb_init( pulses_t *mp )
{
	struct tc_config config_tc;

	mp->output_state = 1;
	mp->my_pulsecount = 0;
	mp->pulsedone = 0;
	
	


	tc_get_config_defaults(&config_tc);

	config_tc.counter_size    = TC_COUNTER_SIZE_16BIT;
	config_tc.wave_generation = TC_WAVE_GENERATION_NORMAL_FREQ;
	config_tc.counter_16_bit.compare_capture_channel[0] = (mp->time_on) * 48000000 / 65536;
	config_tc.clock_prescaler = TC_CLOCK_PRESCALER_DIV1;
	config_tc.enable_capture_on_channel[TC_COMPARE_CAPTURE_CHANNEL_0] = true;
	config_tc.pwm_channel[TC_COMPARE_CAPTURE_CHANNEL_0].enabled = true;
	
	tc_init(&tc_instance, TC4, &config_tc);

	tc_enable(&tc_instance);
	//turn output on
	
	//Enable Callbacks
	
	tc_register_callback(&tc_instance, hb_beat,	TC_COMPARE_CAPTURE_CHANNEL_0);
	tc_enable_callback(&tc_instance, TC_COMPARE_CAPTURE_CHANNEL_0);
}
	
// void delays(int D) {
// 
// 	
// }
	
