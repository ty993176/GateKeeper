/*
 * serial_interface.c
 *
 * Created: 4/14/2022 3:06:26 PM
 *  Author: st991970
 */ 


#include <asf.h>
#include <stdio.h>
#include <string.h>
#include "application.h"
#include "serial_interface.h"
#include "firing_board.h"
#include "supply.h"
#include "hb.h"
uint8_t board_info_sent = BOARD_INFO_NOT_SENT;
int Channel = 0;
float pulseD = 0;
uint32_t Duty = 0;
uint32_t Duty_off = 0;
uint8_t response;
unsigned int psc3;

static void print_help(unsigned char command)
{
	if (command == HELP_GENERAL){
		printf("For more information on a specific command, type HELP command-name\r\n\r\n");
		printf("DEAD		Inserts dead time in the pump.\r\n");
		printf("FREQUENCY	Stop the stack pump, then sets the output oscillator\r\n");
		printf("PON			Enables the mains relay.\r\n");
		printf("POFF		Disables the mains relay.\r\n");
		printf("PULSE		Pulses the high side switch between 1ms and 100ms.\r\n");
		printf("RESET		Performs a soft reset of the control card.\r\n");
		printf("START		Starts the stack pump.\r\n");
		printf("STOP		Stops the stack pump.\r\n");
	}else if (command == HELP_PON){
		printf("Enable the mains relay.  There are no parameters to this function.\r\n");
	}else if (command == HELP_POFF){
		printf("Disables the mains relay.  There are no parameters to this function.\r\n");
	}else if (command == HELP_PULSE){
		printf("Pulses the high side switch between 1ms and 100ms.\r\n");
		printf("PULSE [On Time mS]\r\n");
	}else if (command == HELP_FREQUENCY){
		printf("Stops the stack pump, then sets the output oscillator.\r\n");
		printf("Finally restarts the stack pump at the new frequency.\r\n\r\n");
		printf("FREQUENCY [Hz]\r\n");		
	}
}

void si_command(volatile uint8_t *uart_buffer)
{
	char my_buffer[UART_BUFFER_SIZE];
	unsigned char c = 0;
	char *tokenA = 0;
	char *tokenB = 0;
	char *tokenC = 0;
	char *tokenD = 0;
	char *tokenE = 0;
	char *tokenF = 0;
	char *tokenG = 0;
	char *tokenH = 0;
	char *tokenI = 0;
	char *tokenJ = 0;
		
	const char s[2] = " ";

	//comm.receive_inhibit = 1;

	//remove volatile qualifier
	for (c=0;c<UART_BUFFER_SIZE;c++)
	{
		my_buffer[c] = uart_buffer[c];
	}

	//Get Tokens
	tokenA = strtok(my_buffer,s);
	if (tokenA != NULL)
	{
		tokenB = strtok(NULL,s);
		if (tokenB != NULL)
		{
			tokenC = strtok(NULL,s);
			if (tokenC !=NULL)
			{
				tokenD = strtok(NULL,s);
				if (tokenD !=NULL)
				{
					tokenE = strtok(NULL,s);
					if (tokenE !=NULL)
					{
						tokenF = strtok(NULL,s);
						if (tokenF !=NULL)
						{
							tokenG = strtok(NULL,s);
							if (tokenG !=NULL)
							{
								tokenH = strtok(NULL,s);
								if (tokenH !=NULL)
								{
									tokenI = strtok(NULL,s);
									if (tokenI !=NULL)
									{
										tokenJ = strtok(NULL,s);
								
									}
									
								}
							}
						}
					}
				}
			}
		}
	}
		
	//Start Testing tokens
	if (strcasecmp(tokenA, "PLS") == 0) {
		
		my_pulse.channelst = atoi(tokenB);
		my_pulse.channelnxt = atoi(tokenC);
		my_pulse.channelend = atoi(tokenD);
		my_pulse.pulsecount = atoi(tokenE);
		my_pulse.cycles = atoi(tokenF);
		my_pulse.time_on = atoi(tokenG);
		my_pulse.time_on = my_pulse.time_on / 1000;
		my_pulse.time_off = atoi(tokenH);
		my_pulse.time_off = my_pulse.time_off / 1000;
		my_pulse.my_cycle_count = 0;
		my_pulse.my_pulsecount = 0;
		my_pulse.pausedur = atoi(tokenI);
		my_pulse.pausedur = my_pulse.pausedur / 1000;
		boardnum = atoi(tokenJ);
		
		ps_pulse(&my_pulse, boardnum);
			
	}else if (strcasecmp(tokenA, "PULSE") == 0) {
		if(strcasecmp(tokenB, "STOP") == 0) {
			tc_disable(&tc_instance);
			port_pin_set_output_level(EN_FIRE_1, false);
			port_pin_set_output_level(EN_FIRE_2, false);
			port_pin_set_output_level(EN_FIRE_3, false);
			port_pin_set_output_level(EN_FIRE_4, false);
			port_pin_set_output_level(EN_FIRE_5, false);
			port_pin_set_output_level(EN_FIRE_6, false);
			port_pin_set_output_level(EN_FIRE_7, false);
			port_pin_set_output_level(EN_FIRE_8, false);
			Channel = 0;
			stdio_serial_init(&usart_command, COMMAND_USART_MODULE1, &config_f_usart);
			printf("PULSING STOP\r\n");
			response = 1;
		} 
	
	}else if (strcasecmp(tokenA, "FTEST") == 0) {
		stdio_serial_init(&usart_command, COMMAND_USART_MODULE1, &config_f_usart);
		printf("F RETURN\r\n");
	}else if (strcasecmp(tokenA, "A") == 0){
		if (tokenB == NULL)
		{
			//We want to ignore this entire packet
			return;
		}
		if (tokenC == NULL)
		{
			//We have sent a duration, please let it be a number
			return;			
		}
		//If code is running, pass to firingboard
		
		//fb_command(uart_buffer);
	}else if (strcasecmp(tokenA,"WHO") == 0){
		if (board_info_sent == BOARD_INFO_NOT_SENT)
		{
			printf("A 8\r\n");
			//board_info_sent = BOARD_INFO_SENT;
		}
	}else if(strcasecmp(tokenA, "PULSING") == 0){
		if(strcasecmp(tokenB , "DONE") == 0){
			stdio_serial_init(&usart_command, COMMAND_USART_MODULE1, &config_f_usart);
			printf("PULSING DONE\r\n");
		}else if(strcasecmp(tokenB, "STOP") == 0){
			stdio_serial_init(&usart_command, COMMAND_USART_MODULE1, &config_f_usart);
			printf("PULSING STOP\r\n");
		}else if(strcasecmp(tokenB, "STARTED") == 0){
			stdio_serial_init(&usart_command, COMMAND_USART_MODULE1, &config_f_usart);
			printf("PULSING STARTED\r\n");
		}else{
			stdio_serial_init(&usart_command, COMMAND_USART_MODULE1, &config_f_usart);
			printf("PULSING ERROR\r\n");
		}
		
	}
	memset_volatile(&uart_buffer,0,sizeof(uart_buffer));
}
	
	
