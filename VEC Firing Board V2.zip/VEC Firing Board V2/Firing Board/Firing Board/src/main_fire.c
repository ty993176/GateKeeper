/**
 * \file
 *
 * \brief SAM USART Quick Start
 *
 * Copyright (c) 2012-2018 Microchip Technology Inc. and its subsidiaries.
 *
 * \asf_license_start
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip
 * software and any derivatives exclusively with Microchip products.
 * It is your responsibility to comply with third party license terms applicable
 * to your use of third party software (including open source software) that
 * may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE,
 * INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY,
 * AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE
 * LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL
 * LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE
 * SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE
 * POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT
 * ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY
 * RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
 * THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * \asf_license_stop
 *
 */
/*
 * Support and FAQ: visit <a href="https://www.microchip.com/support/">Microchip Support</a>
 */
#include <asf.h>
#include <stdio.h>
#include <string.h>
#include "application.h"
#include "serial_interface.h"
#include "firing_board.h"
#include "comms.h"
#include "supply.h"
#include "system_interrupt.h"
#include "hb.h"

struct usart_config cb_config;
struct usart_module cb_instance;
struct usart_module usart_command;

//void usart_read_callback(struct usart_module *const usart_module);
void usart_write_callback(struct usart_module *const usart_module);

void who_are_you(void);


//! [module_inst]
struct usart_module usart_instance;
//! [module_inst]

//! [rx_buffer_var]


board_t boards[4];

//volatile uint8_t rx_buffer[MAX_RX_BUFFER_LENGTH];
volatile uint8_t my_buffer[32];
volatile uint8_t fb_buffer[32];
volatile uint8_t my_buffer_index = 0;

//volatile uint8_t my_events = 0;
volatile uint8_t board_ident = 0;

volatile unsigned int my_counter = 0;

//! [rx_buffer_var]

//! [callback_funcs]
void usart_read_callback(struct usart_module *const usart_module)
{
	
	if (rx_buffer[0] == ASCII_LF) {
		//return;
	}else if (rx_buffer[0] == ASCII_CR)
	{
		event_flags |= (1<<EVENT_USART_RECEIVE);
		
		return;
	}else if ((event_flags & (1 << EVENT_USART_RECEIVE)) == 0) {
		my_buffer[my_buffer_index++] = rx_buffer[0];
	}else{
		return;
	}
	
}

void handle_events( void )
{
	

		
	if (event_flags  & (1<<EVENT_USART_RECEIVE))
	{
		si_command(my_buffer);
		event_flags &= ~(1<<EVENT_USART_RECEIVE);
		rx_buffer[0] = 0;
		unsigned char b = 0;
		for(b=0;b<32;b++)
			my_buffer[b] = 0;
		
		my_buffer_index = 0;
	}else if (event_flags & (1<<EF_COMMAND_2)) {
		my_buffer_index = 0;
		memset_volatile(&rx_buffer,0,sizeof(rx_buffer));
		event_flags &= ~(1<<EF_COMMAND_2);
	}
}

	//! [setup_change_config]

	//! [setup_set_config]
	

//! [setup_enable]
	//usart_enable(&usart_instance);
//! [setup_enable]
	//stdio_serial_init(&usart_instance,COMMAND_USART_MODULE1, &config_usart);
//! [setup]

// Enumerates the board number. If there is nothing assigned to the board, it becomes board A. If it is already assigned a letter, the next board in line is incremented to the next letter.
// void who_are_you(void) {
// 	char board = 0;
// 	int channel = 0;
// 	long int start_time = 0, duration = 0;
// 	uint32_t boardnum[4] = {board, channel, start_time, duration};
// 	//IF first firing board after control, boardnum[0-4] = A 0 0 0
// 	if(boardnum[0] == 0) {
// 		boardnum[0] = 'A';
// 		board_ident = boardnum[0];
// 	}
// 	else if(boardnum[0] != 0){
// 		boardnum[0] = boardnum[0] + 1;
// 		board_ident = boardnum[0];
// 	}
// 	if(/*Check for below boards*/) {
// 		
// 	}
//}

void clear_command_buffer( void )
{
	//Clear command buffer
	unsigned char c = 0;
	for (c=0;c<32;c++)
	{
		my_buffer[c] = 0;
		fb_buffer[c] = 0;
	}
	my_buffer_index = 0;
	
}
//Control of firing board command

int main(void)
{
	system_init();

	system_interrupt_enable_global();
	clear_command_buffer();
	
	tc_disable(&tc_instance);
	//tc_disable_callback(&tc_instance, TC_COMPARE_CAPTURE_CHANNEL_0);
	
//! [setup_init]

//! [setup_init]

//! [main]
//! [enable_global_interrupts]
//! [enable_global_interrupts]

//! [main_send_string]
	
//! [main_send_string]
	event_flags = 0;

	//who_are_you();
	
//! [main_loop] 
	while (1) {
//! [main_loop]
//! [main_read]
		
		handle_events();
		usart_read_buffer_job(&usart_command,
				(uint8_t *)rx_buffer, MAX_RX_BUFFER_LENGTH);
		//port_pin_set_output_level(EN_FIRE_1, true);		
			

//! [main_read]

	}
//! [main]
}

