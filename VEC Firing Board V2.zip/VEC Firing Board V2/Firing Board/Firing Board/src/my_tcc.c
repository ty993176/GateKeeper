/*
 * my_tcc.c
 *
 * Created: 8/9/2023 10:05:14 AM
 *  Author: ty993176
 */ 

#include <asf.h>
#include "application.h"
#include "my_tcc.h"
//#include "conf_quick_start_callback.h"

struct tcc_module tcc_instance;
struct tcc_config config_tcc;

volatile bool duty_changed = false;


static void tcc_callback_to_change_duty_cycle(
struct tcc_module *const module_inst)
{
// 	return;
// 	static uint32_t delay = 5;
// 	static uint32_t i = 0;
// 	
// 	if (--delay) {
// 		return;
// 	}
// 	delay = 5;
// 	i = (i + 0x0800) & 0xFFFF;
// 	//i = (i + 0x0700) & 0xFFFF;
// 	// 		tcc_set_compare_value(module_inst,
// 	// 				(enum tcc_match_capture_channel)
// 	// 				(CH1),
// 	// 				i+1);
// 	tcc_set_compare_value(module_inst,
// 	(enum tcc_match_capture_channel)
// 	(CH1),
// 	i+1);
// 	// 		tcc_set_compare_value(module_inst,
// 	// 			(enum tcc_match_capture_channel)
// 	// 			(CH2),
// 	// 			i+1);
	
}
void configure_tcc_callbacks(void)
{
// 	//! [setup_register_callback]
// 	tcc_register_callback(
// 	&tcc_instance,
// 	tcc_callback_to_change_duty_cycle,
// 	(enum tcc_callback)(TCC0 + CH1));
// 
// 	//! [setup_register_callback]
// 
// 	//! [setup_enable_callback]
// 	tcc_enable_callback(&tcc_instance,
// 	(enum tcc_callback)(TCC0 + CH1));
// 	//! [setup_enable_callback]
}


void my_tcc_enable( void )
{
	tcc_enable(&tcc_instance);
}

void my_tcc_disable( void )
{
	tcc_disable(&tcc_instance);
}

void tcc_update(application_t *a)
{

	
}

static bool tcc_initialized = false;

void my_tcc_configure(application_t *a)
{
// 	system_interrupt_disable_global();
// 	// 	unsigned int freq = 5000;
// 	// 	a->period = 1000000*46.6/freq;
// 	// 	a->match = a->period / 2;
// 	// 	a->dead_high = 10;
// 	// 	a->dead_low = 10;
// 	
// 	//! [setup_config]
// 	
// 	//! [setup_config]
// 	//! [setup_config_defaults]
// 	tcc_get_config_defaults(&config_tcc, Q1_MODULE);
// 	//tcc_get_config_defaults(&config_tcc, TCC0);
// 
// 	//! [setup_config_defaults]
// 	config_tcc.counter.clock_source = GCLK_GENERATOR_0; //| GCLK_CLKCTRL_CLKEN | GCLK_CLKCTRL_ID(0x1A);
// 	config_tcc.counter.clock_prescaler = TCC_CLOCK_PRESCALER_DIV1;
// 	//! [setup_change_config]
// 	//config_tcc.counter.period = a->period;
// 	/*config_tcc.counter.period = 1000;*/
// 	config_tcc.counter.period = 932;
// 	config_tcc.compare.wave_generation = TCC_WAVE_GENERATION_SINGLE_SLOPE_PWM;
// 	
// 	//config_tcc.compare.match[CH1] = a->match;
// 	//config_tcc.compare.match[CH2] = a->match;
// 	config_tcc.compare.match[CH1] = 932;
// 	config_tcc.compare.match[CH2] = 0;
// 	/*configure_tcc_callbacks();*/
// 	// 	tcc_set_compare_value(&tcc_instance,
// 	// 	(CH1),
// 	// 	config_tcc.compare.match[CH1]);
// 	// 	//! [setup_change_config]
// 
// 	//! [setup_change_config_pwm]
// 
// 	config_tcc.pins.enable_wave_out_pin[Q1_OUTPUT]		= true;
// 	config_tcc.pins.wave_out_pin[Q1_OUTPUT]				= Q1_PIN;
// 	config_tcc.pins.wave_out_pin_mux[Q1_OUTPUT]			= Q1_MUX;
// 	config_tcc.wave_ext.invert[Q1_OUTPUT]				= false;
// 
// 	config_tcc.pins.enable_wave_out_pin[Q2_OUTPUT]		= true;
// 	config_tcc.pins.wave_out_pin[Q2_OUTPUT]				= Q2_PIN;
// 	config_tcc.pins.wave_out_pin_mux[Q2_OUTPUT]			= Q2_MUX;
// 	config_tcc.wave_ext.invert[Q2_OUTPUT]				= false;
// 	//! [setup_set_config]
// 	tcc_instance.hw = Q1_MODULE;
// 	enum status_code sc;
// 	if(tcc_initialized) {
// 		return;
// 	}
// 	sc = tcc_init(&tcc_instance, Q1_MODULE, &config_tcc);
// 	//tcc_init(&tcc_instance, Q1_MODULE, &config_tcc);
// 	tcc_initialized = true;
// 	if (sc)
// 	{
// 		printf("\r\nStatus code: %0x\r\n",sc);
// 	}
// 	
// 	//! [setup_set_config]
// 	TCC0->WEXCTRL.reg =
// 	TCC_WEXCTRL_DTIEN0 |
// 	TCC_WEXCTRL_DTIEN1 |
// 	TCC_WEXCTRL_DTIEN2 |
// 	TCC_WEXCTRL_DTIEN3;
// 	TCC0->WEXCTRL.reg |= TCC_WEXCTRL_DTLS(a->dead_low);
// 	TCC0->WEXCTRL.reg |= TCC_WEXCTRL_DTHS(a->dead_high);
// 	TCC0->WEXCTRL.reg |= TCC_WEXCTRL_OTMX(1);
// 	//! [setup_enable]
// 	tcc_enable(&tcc_instance);
// 	//! [setup_enable]
// 	system_interrupt_enable_global();
}