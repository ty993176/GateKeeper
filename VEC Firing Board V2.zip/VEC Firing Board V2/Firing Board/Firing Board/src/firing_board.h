/*
 * firing_board.h
 *
 * Created: 8/29/2022 9:15:21 AM
 *  Author: ty993176
 */ 


#ifndef FIRING_BOARD_H_
#define FIRING_BOARD_H_

#define FIRING_BOARD_1	1
#define FIRING_BOARD_2	2
#define FIRING_BOARD_3	3


//void delay(int milliseconds);
void fb_control(void);
void fb_command(volatile uint8_t *uart_buffer);
void ps_pulse(pulses_t *pulses, int board);

#endif /* FIRING_BOARD_H_ */