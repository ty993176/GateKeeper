/*
 * IncFile1.h
 *
 * Created: 8/9/2023 9:50:49 AM
 *  Author: ty993176
 */ 


#ifndef HB_H_
#define HB_H_

// typedef struct{
// 	uint32_t channelst;
// 	uint32_t channelnxt;
// 	uint32_t channelend;
// 	uint32_t pausedur;
// 	uint32_t pulsecount;
// 	uint32_t my_pulsecount;
// 	uint32_t cycles;
// 	uint32_t my_cycle_count;
// 	uint32_t newpulse;
// 	float time_on;
// 	float time_off;
// 	uint8_t output_state;
// 	uint8_t channel;
// 	uint8_t pulsedone;
// 	
// }pulses_t;
// 
pulses_t my_pulse;
extern int boardnum;

void hb_beat( struct tc_module *const module_inst );
void hb_init( pulses_t *mp );
void delays(int D);

extern struct tc_module tc_instance;

#endif /* INCFILE1_H_ */