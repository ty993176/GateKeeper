/*
 * FIRING_BOARD.c
 *
 * Created: 8/23/2022 12:00:11 PM
 *  Author: ty993176
 */ 


#include <asf.h>
#include <stdio.h>
#include <string.h>
#include "application.h"
#include "serial_interface.h"
#include "firing_board.h"
#include "hb.h"

int chantemp;
int boardnum = 0;
// 
// static void fb_help(unsigned char command)
// {
// 	if (command == HELP_GENERAL){
// 		
// 		}else if (command == HELP_PON){
// 		
// 		}else if (command == HELP_POFF){
// 		
// 		}else if (command == HELP_PULSE){
// 		
// 		}else if (command == HELP_FREQUENCY){
// 		
// 	}
// }

void ps_pulse(pulses_t *pulses, int board) {
	
	chantemp = pulses->channelnxt - 8*boardnum;
	if(chantemp <=  8) {
		
		if (chantemp == 1) {
			pulses->channel = EN_FIRE_1;
			//pulse(Channel, Duty, pulseD);
			}else if (chantemp == 2) {
			pulses->channel = EN_FIRE_2;
			//pulse(Channel, Duty, pulseD);
			}else if (chantemp == 3) {
			pulses->channel = EN_FIRE_3;
			//pulse(Channel, Duty, pulseD);
			}else if (chantemp == 4) {
			pulses->channel = EN_FIRE_4;
			//pulse(Channel, Duty, pulseD);
			}else if (chantemp == 5) {
			pulses->channel = EN_FIRE_5;
			//pulse(Channel, Duty, pulseD);
			}else if (chantemp == 6) {
			pulses->channel = EN_FIRE_6;
			//pulse(Channel, Duty, pulseD);
			}else if (chantemp == 7) {
			pulses->channel = EN_FIRE_7;
			//pulse(Channel, Duty, pulseD);
			}else if (chantemp == 8) {
			pulses->channel = EN_FIRE_8;
			//pulse(Channel, Duty, pulseD);
			}
 		stdio_serial_init(&usart_command, COMMAND_USART_MODULE1, &config_f_usart);
		if(my_pulse.channelnxt == 1){
			
 			printf("PULSING STARTED\r\n");
		}
		psc3 = 0;
		hb_init(&pulses);
		
	}else {
		boardnum++;
 		stdio_serial_init(&usart_command1, COMMAND_USART_MODULE2, &config_f2_usart);
 		printf("PLS  %lu %lu %lu %lu %lu %lu %lu %lu %u \r\n", pulses->channelst, pulses->channelnxt, pulses->channelend, pulses->pulsecount, pulses->cycles, pulses->time_on, pulses->time_off, pulses->pausedur, boardnum);
		tc_disable(&tc_instance);
		tc_disable_callback(&tc_instance, TC_COMPARE_CAPTURE_CHANNEL_0);
	}
}
	
	//Start Testing tokens
// 	if (strcasecmp(tokenA,"FIRE") == 0)
// 	{
// 		MAINS_ENABLE;
// 		}else if(strcasecmp(tokenA, "CEASE") == 0){
// 		MAINS_DISABLE;
// 		}else if (strcasecmp(tokenA, "PULSE") == 0){
// 		unsigned int delay = 0;
// 		if (tokenB != NULL)
// 		{
// 			delay = atoi(tokenB);
// // 			if ((delay>0) && (delay<100))
// // 			{
// // 				//Pulse duration is in the acceptable range
// // 				HS_ON;
// // 				//delay_ms(pulse_delay);
// // 				HS_OFF;
// // 				}else{
// // 				printf("Please select a pulse duration between 1ms and 100ms.\r\n");
// 			}
// 		}
// 		}else if (strcasecmp(tokenA, "HELP") == 0){
// 		if (strcasecmp(tokenB, "PON") == 0){
// 			//print_help(HELP_PON);
// 			}else if(strcasecmp(tokenB, "POFF") == 0){
// 			//print_help(HELP_POFF);
// 			}else if (strcasecmp(tokenB, "PULSE") == 0){
// 			//print_help(HELP_PULSE);
// 			}else{
// 			//print_help(HELP_GENERAL);
// 		}
// 	}
//}
