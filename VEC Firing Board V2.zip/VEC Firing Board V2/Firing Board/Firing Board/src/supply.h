/*
 * IncFile1.h
 *
 * Created: 8/11/2022 2:29:45 PM
 *  Author: ty993176
 */ 


#ifndef SUPPLY_H_
#define SUPPLY_H_

extern uint8_t response;

void memset_volatile(volatile void *s, char c, size_t n);
//void pulse(my_pulse *pn);
//void delay_ms(float duration);
void handle_events(void);
void clear_command_buffer(void);
#endif /* SUPPLY_H_ */