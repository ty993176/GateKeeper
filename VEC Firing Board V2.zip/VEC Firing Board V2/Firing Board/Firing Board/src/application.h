/*
 * application.h
 *
 * Created: 4/13/2022 5:23:07 PM
 *  Author: st991970
 */ 


#ifndef APPLICATION_H_
#define APPLICATION_H_

//Pin Definitions
#define LED1_PIN		PIN_PA13
#define LED2_PIN		PIN_PA12
#define LED3_PIN		PIN_PB15
#define LED4_PIN		PIN_PB14
#define LED5_PIN		PIN_PB13
#define LED6_PIN		PIN_PB12
#define LED_ACTIVE		false
#define LED_INACTIVE	true

#define HS_SWITCH		PIN_PB31
#define EN_MAINS		PIN_PB03
#define EN_FIRE_1		PIN_PB09
#define EN_FIRE_2		PIN_PB08
#define EN_FIRE_3		PIN_PB07
#define EN_FIRE_4		PIN_PB06
#define EN_FIRE_5		PIN_PA07
#define EN_FIRE_6		PIN_PA06
#define EN_FIRE_7		PIN_PA05
#define EN_FIRE_8		PIN_PA04
#define EN_DRAIN_L		PIN_PA04
#define EN_DRAIN_BUS	PIN_PA06
#define DATA_0			PIN_PA20
#define DATA_1			PIN_PA21
#define DATA_2			PIN_PA22
#define DATA_3			PIN_PA23
#define DATA_4			PIN_PA24
#define DATA_5			PIN_PA25

#define	PS1				PIN_PB00
#define PS2				PIN_PB01
#define PS3				PIN_PB02
#define PS4				PIN_PB03


//Usart Definitions
#define COMMAND_USART_MODULE		SERCOM0
#define COMMAND_USART_MODULE1		SERCOM1
#define COMMAND_USART_MODULE2		SERCOM2
#define COMMAND_USART_MODULE3		SERCOM3

#define COMMAND_USART_MUX_SETTINGS	USART_RX_2_TX_0_XCK_1		// ETHERNET RX/TX
#define COMMAND_USART_MUX_SETTINGS1 USART_RX_1_TX_0_XCK_1		// SERIAL BOARD COMM RX/TX   -   CONTROL
#define COMMAND_USART_MUX_SETTINGS2	USART_RX_2_TX_0_XCK_1		// SERIAL BOARD COMM RX/TX   -   NANITE
#define COMMAND_USART_MUX_SETTINGS3	USART_RX_1_TX_0_XCK_1		// SERIAL BOARD COMM RX1/TX1 -   NANITE

#define MAX_RX_BUFFER_LENGTH   1
volatile uint8_t rx_buffer[MAX_RX_BUFFER_LENGTH];

#define COMMAND_USART_PINMUX_PAD0	PINMUX_UNUSED		// From Nanite to Below
#define COMMAND_USART_PINMUX_PAD1	PINMUX_PA09D_SERCOM2_PAD1
#define COMMAND_USART_PINMUX_PAD2	PINMUX_PA10D_SERCOM2_PAD2
#define COMMAND_USART_PINMUX_PAD3	PINMUX_UNUSED

#define COMMAND_USART_PINMUX_PAD0_1	PINMUX_PA16C_SERCOM1_PAD0	// From Above to Nanite and Control to Nanite
#define COMMAND_USART_PINMUX_PAD1_1	PINMUX_PA17C_SERCOM1_PAD1
#define COMMAND_USART_PINMUX_PAD2_1	PINMUX_UNUSED
#define COMMAND_USART_PINMUX_PAD3_1	PINMUX_UNUSED

// #define COMMAND_USART_PINMUX_PAD0_2	PINMUX_PA08D_SERCOM2_PAD0	// Nanite 
// #define COMMAND_USART_PINMUX_PAD1_2	PINMUX_UNUSED
// #define COMMAND_USART_PINMUX_PAD2_2	PINMUX_PA10D_SERCOM2_PAD2
// #define COMMAND_USART_PINMUX_PAD3_2	PINMUX_UNUSED
// 
// #define COMMAND_USART_PINMUX_PAD0_3	PINMUX_PA16D_SERCOM3_PAD0	// Nanite below
// #define COMMAND_USART_PINMUX_PAD1_3	PINMUX_PA17D_SERCOM3_PAD1
// #define COMMAND_USART_PINMUX_PAD2_3	PINMUX_UNUSED
// #define COMMAND_USART_PINMUX_PAD3_3	PINMUX_UNUSED


#define COMMAND_USART_BAUDRATE		9600
#define UART_BUFFER_SIZE			32
#define FB_BUFFER_SIZE				32

//Port Pin Macros
#define MAINS_ENABLE				port_pin_set_output_level(EN_MAINS,true)
#define MAINS_DISABLE				port_pin_set_output_level(EN_MAINS,false)
#define FIRE_ENABLE_1				port_pin_set_output_level(EN_FIRE_1,true)
#define FIRE_DISABLE_1				port_pin_set_output_level(EN_FIRE_1,false)
#define FIRE_ENABLE_2				port_pin_set_output_level(EN_FIRE_2,true)
#define FIRE_DISABLE_2				port_pin_set_output_level(EN_FIRE_2,false)
#define FIRE_ENABLE_3				port_pin_set_output_level(EN_FIRE_3,true)
#define FIRE_DISABLE_3				port_pin_set_output_level(EN_FIRE_3,false)
#define FIRE_ENABLE_4				port_pin_set_output_level(EN_FIRE_4,true)
#define FIRE_DISABLE_4				port_pin_set_output_level(EN_FIRE_4,false)
#define FIRE_ENABLE_5				port_pin_set_output_level(EN_FIRE_5,true)
#define FIRE_DISABLE_5				port_pin_set_output_level(EN_FIRE_5,false)
#define FIRE_ENABLE_6				port_pin_set_output_level(EN_FIRE_6,true)
#define FIRE_DISABLE_6				port_pin_set_output_level(EN_FIRE_6,false)
#define FIRE_ENABLE_7				port_pin_set_output_level(EN_FIRE_7,true)
#define FIRE_DISABLE_7				port_pin_set_output_level(EN_FIRE_7,false)
#define FIRE_ENABLE_8				port_pin_set_output_level(EN_FIRE_8,true)
#define FIRE_DISABLE_8				port_pin_set_output_level(EN_FIRE_8,false)
#define DRAIN_BUS_ENABLE			MAINS_DISABLE;port_pin_set_output_level(EN_DRAIN_BUS,true)
#define DRAIN_BUS_DISABLE			port_pin_set_output_level(EN_DRAIN_BUS,false)
#define HS_ON						port_pin_set_output_level(HS_SWITCH,true)
#define HS_OFF						port_pin_set_output_level(HS_SWITCH,false)
#define DRAIN_L_ENABLE				port_pin_set_output_level(EN_DRAIN_L,true)
#define DRAIN_L_DISABLE				port_pin_set_output_level(EN_DRAIN_L,false)

//Help Instruction constants
#define HELP_GENERAL				0
#define HELP_PON					1
#define HELP_POFF					2
#define HELP_PULSE					3
#define HELP_FREQUENCY				4

//ASCII Constants
#define ASCII_CR					13
#define ASCII_LF					10
#define ASCII_BACKSPACE				8			//Check this one
#define ACK							0x06
#define NAK							0x15

//Event Constants
#define EVENT_USART_RECEIVE			1
#define EF_COMMAND_2				2

//Structures
typedef struct  
{
	unsigned char board_number;
	unsigned char output_count;
	
}board_t;

typedef struct{
	uint32_t		period;
	uint32_t		match;
	unsigned char	dead_high;
	unsigned char	dead_low;
	uint32_t		frequency;
	float			kgain;
	float			ti;
	float			td;
	float			delT;
	float			lowlim;
	float			highlim;
	
}application_t;

typedef struct application{
	uint32_t channelst;
	uint32_t channelnxt;
	uint32_t channelend;
	uint32_t pausedur;
	uint32_t pulsecount;
	uint32_t my_pulsecount;
	uint32_t cycles;
	uint32_t my_cycle_count;
	uint32_t newpulse;
	float time_on;
	float time_off;
	uint8_t output_state;
	uint8_t channel;
	uint8_t pulsedone;
	
}pulses_t;



//external Variables
extern struct usart_module usart_command;
extern struct usart_module usart_command1;
extern struct usart_module f_instance;
extern struct usart_config f_config;
extern struct usart_config config_f_usart;
extern struct usart_config config_f2_usart;
extern volatile uint32_t command_tx_buffer[UART_BUFFER_SIZE];
extern volatile uint32_t command_rx_buffer[UART_BUFFER_SIZE];
extern volatile uint8_t board_ident;
extern volatile unsigned int my_counter;
extern int Channel;
extern float pulseD;
extern uint32_t Duty;
extern uint32_t Duty_off;
extern unsigned int psc3;
extern pulses_t my_pulse;

#endif /* APPLICATION_H_ */