/*
 * CFile1.c
 *
 * Created: 8/10/2022 2:06:09 PM
 *  Author: ty993176
 */ 


#include <asf.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include "application.h"
#include "supply.h"

volatile uint8_t cb_count = 0;
uint8_t response;

void memset_volatile(volatile void *s, char c, size_t n)
{
	volatile char *p = s;
	while (n-- > 0) {
		*p++ = c;
	}
}


// void pulse(pulses_t *pn) {
// 
// 	if (pn->pulsedone == 1) {
// 		pn->channelnxt++;
// 		
// 		pn->pulsedone = 0;
// 		
// 	}
// 	
// 
// }