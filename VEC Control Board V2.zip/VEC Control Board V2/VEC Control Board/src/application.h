/*
 * application.h
 *
 * Created: 8/19/2022 6:22:16 PM
 *  Author: st991970
 */ 


#ifndef APPLICATION_H_
#define APPLICATION_H_

#define UART_BUFFER_SIZE			32
#define VT_ESC						27
#define VT_BG_PURPLE				printf("%c]11;#53186f7",VT_ESC)
#define VT_CLEAR_SCREEN				printf("%c[2J%c[H",VT_ESC,VT_ESC)

#define VT_CR						0x0D
#define VT_LF						0x0A
#define VT_FF						0x0C
#define VT_BS						0x08
#define VT_SP						0x20
#define VT_ACK						0x06
#define VT_NAK						0x15

#define MAX_EVENTS					3
#define EF_UART_COMMAND				0
#define EF_RELAY_COMMAND			2
#define EF_PS_COMMAND				1
#define EF_VT_COMMAND				3

#define EVENT_USART_LANTRONICS		0
#define EVENT_USART_PS				1
#define EVENT_USART_FB				2

//USART
#define COMMAND_BUFFER_SIZE			32

#define MAX_RX_BUFFER_LENGTH			1
#define MAX_TX_BUFFER_LENGTH			32
#define COMMAND_BUFFER_LENGTH			32
//Comms Enumeration
#define DEV_LANTRONIX					1
#define DEV_PS							2
#define DEV_RELAY						3

//Help Definitions
#define HELP_COMMAND_LOAD_SCHEDULE		1
#define HELP_GENERAL					2
#define HELP_MAINS						3



//Comms Definitions
#define LANTRONIX_USART_MODULE			SERCOM0
#define LANTRONIX_USART_MUX_SETTINGS	USART_RX_2_TX_0_XCK_1
#define LANTRONIX_USART_PINMUX_PAD0		PINMUX_PA08C_SERCOM0_PAD0
#define LANTRONIX_USART_PINMUX_PAD1		PINMUX_UNUSED
#define LANTRONIX_USART_PINMUX_PAD2		PINMUX_PA10C_SERCOM0_PAD2
#define LANTRONIX_USART_PINMUX_PAD3		PINMUX_UNUSED
#define LANTRONIX_USART_BAUD_RATE		9600

#define RELAY_USART_MODULE				SERCOM5
#define RELAY_USART_MUX_SETTINGS		USART_RX_1_TX_0_XCK_1
#define RELAY_USART_PINMUX_PAD0			PINMUX_PB16C_SERCOM5_PAD0
#define RELAY_USART_PINMUX_PAD1			PINMUX_PB17C_SERCOM5_PAD1
#define RELAY_USART_PINMUX_PAD2			PINMUX_UNUSED
#define RELAY_USART_PINMUX_PAD3			PINMUX_UNUSED
#define RELAY_USART_BAUD_RATE			9600

#define PS_USART_MODULE					SERCOM1
#define PS_USART_MUX_SETTINGS			USART_RX_1_TX_0_XCK_1
#define PS_USART_PINMUX_PAD0			PINMUX_PA16C_SERCOM1_PAD0
#define PS_USART_PINMUX_PAD1			PINMUX_PA17C_SERCOM1_PAD1
#define PS_USART_PINMUX_PAD2			PINMUX_UNUSED
#define PS_USART_PINMUX_PAD3			PINMUX_UNUSED
#define PS_USART_BAUD_RATE				9600

//LED
#define LED_1_PIN						PIN_PB11
#define LED_2_PIN						PIN_PB12
#define LED_3_PIN						PIN_PB13
#define LED_4_PIN						PIN_PB14
#define LED_5_PIN						PIN_PB15

//PS Hardware Pins
#define PS_IN_SIG_1						PIN_PB00
#define PS_IN_SIG_2						PIN_PB01
#define PS_OUT_SIG_1					PIN_PB02
#define PS_OUT_SIG_2					PIN_PB03
// #define TX_TEST							PIN_PA16
// #define TX_HIGH							port_pin_set_output_level(TX_TEST,true)
// #define TX_LOW							port_pin_set_output_level(TX_TEST,false)

//PS Hardware Macros
#define PS_ENABLE						port_pin_set_output_level(PS_OUT_SIG_1,true)
#define PS_DISABLE						port_pin_set_output_level(PS_OUT_SIG_1,false);

//Compare Macro
#define IS_ASCII						


//Setting Constraints
#define KV_MINIMUM						0.7

typedef enum
{
	Lantronix,
	Relay,
	Power_Supply
}serial_device_t;

typedef struct {
	uint32_t	period;
	uint32_t	match;
	unsigned char dead_high;
	unsigned char dead_low;
	uint32_t	frequency;	
}app_settings_t; 

//Uart Structures
extern struct usart_module lantronix_instance;
extern struct usart_config config_lantronix;
extern struct usart_module ps_instance;
extern struct usart_config config_ps;
extern struct usart_module relay_instance;
extern struct usart_config config_relay;

extern volatile uint8_t lantronix_rx_buffer[MAX_RX_BUFFER_LENGTH];
extern volatile uint8_t lantronix_comand_buffer[COMMAND_BUFFER_LENGTH];

extern volatile uint8_t ps_response_buffer[COMMAND_BUFFER_LENGTH];
extern volatile uint8_t relay_response_buffer[COMMAND_BUFFER_LENGTH];

extern uint8_t ps_response;
extern uint8_t f_response;
extern uint8_t cycle_count;
extern volatile uint8_t callback_count;
extern app_settings_t app_settings;

#endif /* APPLICATION_H_ */