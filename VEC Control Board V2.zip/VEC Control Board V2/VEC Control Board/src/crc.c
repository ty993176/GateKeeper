/*
 * crc.c
 *
 * Created: 9/19/2022 9:29:34 AM
 *  Author: st991970
 */ 

#include "crc.h"

unsigned short get_crc(unsigned char count,unsigned char *ptr)
{
	unsigned short crc; //Calculated CRC
	unsigned char i; //Loop count, bits in byte
	unsigned char data; //Current byte being shifted
	crc = 0xFFFF; // Preset to all 1's, prevent loss of leading zeros
	while(count--)
	{
		data = *ptr++;
		i = 8;
		do
		{
			if((crc ^ data) & 0x01)
			{
				crc >>= 1;
				//x^16 + x^12 + x^4 + x^0 Bitwise Inverted
				crc ^= 0x8408;
			}
			else
				crc >>= 1;
			data >>= 1;
		} while(--i != 0);
	}
	return (~crc);
}