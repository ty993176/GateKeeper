/*
 * serial_interface.h
 *
 * Created: 8/19/2022 6:33:49 PM
 *  Author: st991970
 */ 


#ifndef SERIAL_INTERFACE_H_
#define SERIAL_INTERFACE_H_

#define COMM_STATUS_OK			0
#define COMM_STATUS_TIMEOUT		1


void si_command(volatile uint8_t *uart_buffer);




#endif /* SERIAL_INTERFACE_H_ */