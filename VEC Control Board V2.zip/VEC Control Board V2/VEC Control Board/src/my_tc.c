/*
 * my_tc.c
 *
 * Created: 8/29/2022 6:29:48 PM
 *  Author: st991970
 */ 

#include <asf.h>
#include "application.h"
#include "my_tc.h"

volatile uint8_t callback_count = 0;
struct tc_module tc_instance;

void my_tc_callback_overflow(struct tc_module *const module_inst);
void my_tc_callback_overflow(struct tc_module *const module_inst)
{
	callback_count++;	
}

void my_tc_configure(void)
{
	//! [setup_config]
	struct tc_config config_tc;
	//! [setup_config]
	//! [setup_config_defaults]
	tc_get_config_defaults(&config_tc);
	//! [setup_config_defaults]

	//! [setup_change_config]
	config_tc.counter_size    = TC_COUNTER_SIZE_16BIT;
	config_tc.wave_generation = TC_WAVE_GENERATION_NORMAL_PWM;
	config_tc.counter_16_bit.compare_capture_channel[0] = 0xFFFF;
	//! [setup_change_config]

	//! [setup_change_config_pwm]
	//config_tc.pwm_channel[0].enabled = true;
	//config_tc.pwm_channel[0].pin_out = PWM_OUT_PIN;
	//config_tc.pwm_channel[0].pin_mux = PWM_OUT_MUX;
	//! [setup_change_config_pwm]

	//! [setup_set_config]
	tc_init(&tc_instance, TC3, &config_tc);
	
	
	//! [setup_set_config]

	//! [setup_enable]
	tc_enable(&tc_instance);
	//! [setup_enable]
}

void my_tc_configure_callbacks(void)
{
	//! [setup_register_callback]
	tc_register_callback(&tc_instance,my_tc_callback_overflow,TC_CALLBACK_OVERFLOW);
	//! [setup_register_callback]

	//! [setup_enable_callback]
	tc_enable_callback(&tc_instance, TC_CALLBACK_CC_CHANNEL0);
	//! [setup_enable_callback]
}
