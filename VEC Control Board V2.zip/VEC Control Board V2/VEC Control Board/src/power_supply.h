/*
 * power_supply.h
 *
 * Created: 8/26/2022 2:02:29 PM
 *  Author: st991970
 */ 


#ifndef POWER_SUPPLY_H_
#define POWER_SUPPLY_H_

//Power Supply Communication Flags
#define PS_FLAG_ACK				0
#define PS_FLAG_NAK				1
#define PS_FLAG_FAIL			2
#define PS_FLAG_INVALID			3


//Power Supply Max Data Length
#define PS_MAX_DATA_LENGTH		16
#define F_MAX_DATA_LENGTH		16
//Power Supply Validate Packet Return Value
#define VALIDATE_PACKET_GOOD	0

//Power Supply Commands
#define PS_COMMAND_PING				0x00
#define PS_COMMAND_SET_KV			0x01
#define PS_COMMAND_MAINS			0x02
#define PS_COMMAND_BUS_DISCHARGE	0x03
#define PS_COMMAND_HS_BUS_VOLTAGE	0x04
#define PS_COMMAND_LS_BUS_VOLTAGE	0x05
#define PS_COMMAND_HARDWARE_STATUS	0x06



typedef struct
{
	uint16_t voltage;
	uint8_t pump_status;
	float bus_voltage;
	uint8_t mains_are_enabled;
	uint8_t discharge_is_enabled;
}power_supply_data_t;

typedef struct
{
	uint16_t voltage;
	uint8_t pump_status;
	float bus_voltage;
	uint8_t mains_are_enabled;
	uint8_t discharge_is_enabled;
}fire_data_t;

typedef enum
{
	Not_Used,
	Command,
	Request,
	Response_String,
	Response_Integer,
	Response_Float,
	Response_ACK,
	Response_NAK,
	Packet_Fail,
	None
}packet_type_t;

typedef struct  
{
	uint8_t		  command;
	uint8_t		  length;
	uint8_t		  *data;
	short		  crc;
}packet_t;

typedef enum
{
	Ack,
	Nak,
	Non_standard,
	Timeout
}comm_return_code_t;

typedef enum
{
	Ready,
	Not_Ready
}power_supply_status_t;


extern uint32_t Startchannel;			// Starting at 1.
extern uint32_t Nextchannel;
extern uint32_t Endchannel;				// Up to N channelse
extern uint32_t PlsCnt;					// Amount of pulses per cycle
extern uint32_t Cyclerpts;				// Cycle Repeats
extern uint32_t pulse_width_h;
extern uint32_t pulse_width_l;
extern uint32_t Cyclepause;

/*
Accepts a float as a parameter.  Set's the kv setpoint in the power supply
*/
comm_return_code_t ps_set_kv(float f);
comm_return_code_t ps_test(void);
comm_return_code_t f_test(void);
comm_return_code_t duty_set(float P);
comm_return_code_t ps_pulse(uint32_t chst, uint32_t chnxt, uint32_t chend, uint32_t plscnt, uint32_t cclrpts, uint32_t duty_h, uint32_t duty_l, uint32_t pausdur);
comm_return_code_t ps_pulse_stop(void);

void ps_decode_packet( uint8_t *packet_data );
void ps_read_callback(struct usart_module *const ps_module);
void ps_write_callback(struct usart_module *const ps_module);

comm_return_code_t ps_mains(uint8_t off_on);
comm_return_code_t ps_bus_discharge(uint8_t off_on);
comm_return_code_t ps_get_bus_voltage( float f );
float ps_get_high_side_voltage(void);
void ps_set_hardware_enable(uint8_t off_on);
power_supply_status_t ps_get_hardware_status(void);

#endif /* POWER_SUPPLY_H_ */