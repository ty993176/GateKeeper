/*
 * crc.h
 *
 * Created: 9/19/2022 9:30:03 AM
 *  Author: st991970
 */ 


#ifndef CRC_H_
#define CRC_H_


unsigned short get_crc(unsigned char count,unsigned char *ptr);


#endif /* CRC_H_ */