/*
 * my_tc.h
 *
 * Created: 8/29/2022 6:29:58 PM
 *  Author: st991970
 */ 


#ifndef MY_TC_H_
#define MY_TC_H_

#define TIME250					1
#define TIME500					2
#define TIME1000				4
#define TIMETEST				100

#define TIMER_EXPIRED_250		(callback_count > TIME250)
#define TIMER_EXPIRED_500		(callback_count > TIME500)
#define TIMER_EXPIRED_1000		(callback_count > TIME1000)
#define TIMER_EXPIRED_TEST		(callback_count > TIMETEST)



void my_tc_configure(void);
void my_tc_callback_overflow(struct tc_module *const module_inst);
void my_tc_configure_callbacks(void);

#endif /* TC_H_ */