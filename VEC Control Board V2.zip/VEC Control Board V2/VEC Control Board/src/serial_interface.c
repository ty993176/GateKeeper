
 /* serial_interface.c
 *
 * Created: 8/19/2022 6:34:01 PM
 *  Author: ty993176
 */ 


#include <asf.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "application.h"
#include "serial_interface.h"
#include "settings.h"
#include "public.h"
#include "power_supply.h"

uint32_t Startchannel = 0;
uint32_t Nextchannel = 0;
uint32_t Endchannel = 0;
uint32_t PlsCnt = 0;
uint32_t Cyclerpts = 0;
uint32_t pulse_width_h = 0;
uint32_t pulse_width_l = 0;
uint32_t Cyclepause = 0;

uint8_t cycle_count = 0;

static void print_help(unsigned char command)
{
	settings_usart_destination(Lantronix);
	switch(command)
	{
		case HELP_COMMAND_LOAD_SCHEDULE:
		printf("Add a schedule item.\r\n");
		printf("LOAD,[Index],[Emitter],[Start Time uS], [Stop Time uS]\r\n");
		break;
		case HELP_GENERAL:
		printf("For more information on a specific command, type HELP command-name\r\n\r\n");
		printf("DEAD		Inserts dead time in the pump.\r\n");
		printf("FREQUENCY	Stop the stack pump, then sets the output oscillator\r\n");
		printf("PON			Enables the mains relay.\r\n");
		printf("POFF		Disables the mains relay.\r\n");
		printf("PULSE		Pulses the high side switch between 1ms and 100ms.\r\n");
		printf("RESET		Performs a soft reset of the control card.\r\n");
		printf("START		Starts the stack pump.\r\n");
		printf("STOP		Stops the stack pump.\r\n");
		printf("LOAD	    Used to load a schedule of firing\r\n");
		break;
		case HELP_MAINS:
		printf("PON			Enable the mains relay.  There are no parameters to this function.\r\n");
		printf("POFF		Disables the mains relay.  There are no parameters to this function.\r\n");
		printf("PULSE		Pulses the high side switch between 1ms and 100ms.\r\n");
		printf("PULSE		[On Time mS]\r\n");
		break;
	}
}

/* Handles commands sent from user and completes actions */
void si_command(volatile uint8_t *uart_buffer)
{	
	uint8_t comm_status = COMM_STATUS_OK;
	
	
	port_pin_set_output_level(LED_5_PIN,false);
	
	char my_buffer[UART_BUFFER_SIZE];
	unsigned char c = 0;
	char *tokenA = 0;
	char *tokenB = 0;
	char *tokenC = 0;
	char *tokenD = 0;
	char *tokenE = 0;
	char *tokenF = 0;
	char *tokenG = 0;
	char *tokenH = 0;
	char *tokenI = 0;
		
	const char s[2] = " ";

	//comm.receive_inhibit = 1;

	//remove volatile qualifier
	for (c=0;c<UART_BUFFER_SIZE;c++)
	{
		my_buffer[c] = uart_buffer[c];
	}

// 	printf("Uart Buffer '%s'\r\n",uart_buffer);
// 	printf("my_buffer '%s'\r\n",my_buffer);
	


	//Get Tokens
	tokenA = strtok(my_buffer,s);
	if (tokenA != NULL)
	{
		tokenB = strtok(NULL,s);
		if (tokenB != NULL)
		{
			tokenC = strtok(NULL,s);
			if (tokenC !=NULL)
			{
				tokenD = strtok(NULL,s);
				if (tokenD !=NULL)
				{
					tokenE = strtok(NULL,s);
					if (tokenE !=NULL)
					{
						tokenF = strtok(NULL,s);
						if (tokenF !=NULL)
						{
							tokenG = strtok(NULL,s);
							if (tokenG !=NULL)
							{
								tokenH = strtok(NULL,s);
								if (tokenH !=NULL)
								{
									tokenI = strtok(NULL,s);
				
								}
							}
						}
					}
				}
			}
		}
	}
	//printf("A '%s' B '%s' C '%s' D '%s' E '%s'\r\n",tokenA,tokenB, tokenC, tokenD, tokenE);
	
	//Start Testing Tokens
	if (strcasecmp(tokenA,"HELP") == 0)
	{
		//printf ("Your first token was Help\r\n");
		if (strcasecmp(tokenB, "LOAD") == 0){
			print_help(HELP_COMMAND_LOAD_SCHEDULE);
			}else if(strcasecmp(tokenB, "MAINS") == 0){
			print_help(HELP_MAINS);
			}else{
			print_help(HELP_GENERAL);
			}
	}else if(strcasecmp(tokenA,"REBOOT") == 0){
		printf("Reboot Initiated...");
		struct wdt_conf config_wdt;
		/* Get the Watchdog default configuration */
		wdt_get_config_defaults(&config_wdt);
		config_wdt.clock_source			= GCLK_GENERATOR_0;
		config_wdt.enable				= true;
		wdt_set_config(&config_wdt);
		while(1);			
	}else if(strcasecmp(tokenA,"LIGHTSHOW") == 0){
		port_pin_toggle_output_level(LED_1_PIN);
		port_pin_toggle_output_level(LED_2_PIN);
		port_pin_toggle_output_level(LED_3_PIN);
		port_pin_toggle_output_level(LED_4_PIN);
		port_pin_toggle_output_level(LED_5_PIN);
	}else if(strcasecmp(tokenA,"PS") == 0){
		if (strcasecmp(tokenB,"KV") == 0){
			float request_kv = 0;
			request_kv = atof(tokenC);
			ps_set_kv(request_kv);
			
			
		}else if(strcasecmp(tokenB,"KV?") == 0){
			float kv_feedback = 0;
			ps_get_high_side_voltage();
			
//  			if (comm_status == COMM_STATUS_OK)
// 			{
// 				printf("%f\r\n");
// 			}
		}else if (strcasecmp(tokenB,"BUS_VOLTAGE?") == 0){
			float bus_voltage_fb = 0;
			bus_voltage_fb = ps_get_high_side_voltage();
			
			if (comm_status == COMM_STATUS_OK)
			{
				printf("%f\r\n",bus_voltage_fb);
			}
		}else if (strcasecmp(tokenB,"MAINS") == 0){
			if(strcasecmp(tokenC,"ON") == 0)
			{
				ps_mains(1);
			}else if(strcasecmp(tokenC,"OFF") == 0){
				ps_mains(0);
			}else if(strcasecmp(tokenC, "RON") == 0){
				settings_usart_destination(Lantronix);
				printf("Mains On\r\n");	
			}else if(strcasecmp(tokenC, "ROFF") == 0) {
				settings_usart_destination(Lantronix);
				printf("Mains Off\r\n");
			}else{
				print_help(HELP_MAINS);
			}
		//Set KV
		}else if (strcasecmp(tokenB,"SET_KV") == 0){
			//just in case someone puts a negative number in like an idiot.
			float kv_set = abs(atof(tokenC));
			//Require a setting of 1kV or above 
			if (kv_set < (KV_MINIMUM))
			{
				//This is the default return value for invalid input
				printf("Fail: Value of TokenC: '%s'\r\n",tokenC);
			}else{
				//The set value is over zero
				printf("SET");
				ps_set_kv(kv_set);
			}
		}else if (strcasecmp(tokenB, "TEST") == 0) {
				ps_test();
			}
			if (comm_status == COMM_STATUS_TIMEOUT)
			{
				printf("Failed to communicate with PS\r\n");
			}
			
		}else if (strcasecmp(tokenA, "PLS") == 0) {
		if(strcasecmp(tokenB, "STOP") == 0) {
			ps_pulse_stop();
			}else {
			Startchannel = atoi(tokenB);
			Nextchannel = Startchannel;
			Endchannel = atoi(tokenC);
			PlsCnt = atoi(tokenD);
			Cyclerpts = atoi(tokenE);
			pulse_width_h = atoi(tokenF);
			pulse_width_l = atoi(tokenG);
			Cyclepause = atoi(tokenH);
			cycle_count = 0;
			ps_pulse(Startchannel, Nextchannel, Endchannel, PlsCnt, Cyclerpts, pulse_width_h, pulse_width_l, Cyclepause);
		}
	}else if(strcasecmp(tokenA, "BRUH") == 0) {
			settings_usart_destination(Lantronix);
			printf("CHECK\r\n");		
			
		}else if(strcasecmp(tokenA, "KV") == 0) {
			if(strcasecmp(tokenB, "READ") == 0) {
				uint16_t KV_RES;
				KV_RES = atoi(tokenC);
				settings_usart_destination(Lantronix);
				printf("KV VALUE: %u\r\n", KV_RES);
			}else {
				settings_usart_destination(Lantronix);
				printf("KV SET\r\n");
			}
		}else if (strcasecmp(tokenA,"SAVE") == 0) {
			uint8_t page_data[EEPROM_PAGE_SIZE];
			uint8_t fhb = 0;	//Frequency High Byte
			uint8_t flb = 0;	//Frequency Low Byte
			fhb = (app_settings.frequency & 0xFF00) >> 8;
			flb = (app_settings.frequency & 0x00FF);
		
			eeprom_emulator_read_page(0, page_data);
			page_data[0] = fhb;
			page_data[1] = flb;
		
			eeprom_emulator_write_page(0,page_data);
			eeprom_emulator_commit_page_buffer();
			printf("Saved settings:\r\n");
			//printf("frequency = '%l'\r\n", app_settings.frequency);	
		}else if (strcasecmp(tokenA,"LOAD") == 0){
			
			
	
	}else if(strcasecmp(tokenA, "DUTY") == 0) {
		float D = 0;
		D = atof(tokenB);
		duty_set(D);
		
 	}else if(strcasecmp(tokenA, "PULSING") == 0){
 	if(strcasecmp(tokenB, "STOP") == 0) {
	 	settings_usart_destination(Lantronix);
	 	printf("Pulsing Stopped\r\n");
	 	}else if(strcasecmp(tokenB, "STARTED") == 0){
	 	settings_usart_destination(Lantronix);
	 	printf("Pulsing Started\r\n");
	 	}else if(strcasecmp(tokenB, "DONE") == 0) {
	 	cycle_count++;
	 	if(cycle_count <= Cyclerpts) {		// Set up to send another round of pulsing if cycle repeats > 0
		 	ps_pulse(Startchannel, Nextchannel, Endchannel, PlsCnt, Cyclerpts, pulse_width_h, pulse_width_l, Cyclepause);
		 	}else{
		 	settings_usart_destination(Lantronix);
		 	printf("Pulsing Complete\r\n");
	 	}
	 	
	 	}else {
	 	settings_usart_destination(Lantronix);
	 	printf("ERROR - IMPROPER PULSE RESPONSE\r\n");
 	}
	}else if(strcasecmp(tokenA, "DSET") == 0) {
		settings_usart_destination(Lantronix);
		printf("'%d' PERCENT\r\n", atoi(tokenB));
	}else if(strcasecmp(tokenA, "F") == 0) {
		if(strcasecmp(tokenB, "TEST") == 0) {
			f_test();
		}else if(strcasecmp(tokenB, "RETURN") == 0) {
			settings_usart_destination(Lantronix);
			printf("FIRE WORKS\r\n");
		}
	}else if(strcasecmp(tokenA, "WTF") == 0){
		settings_usart_destination(Lantronix);
		printf("Work\r\n");
	}else{
		printf ("Unknown command '%s'\r\n",tokenA);
	}
	memset_volatile(&uart_buffer,0,sizeof(uart_buffer));
	printf("\r\n>");
	port_pin_set_output_level(LED_5_PIN,true);
}
