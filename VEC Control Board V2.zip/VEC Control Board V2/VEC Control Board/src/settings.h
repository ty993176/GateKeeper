/*
 * settings.h
 *
 * Created: 8/23/2022 10:53:40 AM
 *  Author: st991970
 */ 


#ifndef SETTINGS_H_
#define SETTINGS_H_

void settings_usart_destination( serial_device_t sd );
void clear_command_buffer(void);

#endif /* SETTINGS_H_ */