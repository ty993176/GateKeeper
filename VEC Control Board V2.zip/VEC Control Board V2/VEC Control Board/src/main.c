/**
 * \file
 *
 * \brief SAM USART Quick Start
 *
 * Copyright (c) 2012-2018 Microchip Technology Inc. and its subsidiaries.
 *
 * \asf_license_start
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip
 * software and any derivatives exclusively with Microchip products.
 * It is your responsibility to comply with third party license terms applicable
 * to your use of third party software (including open source software) that
 * may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE,
 * INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY,
 * AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE
 * LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL
 * LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE
 * SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE
 * POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT
 * ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY
 * RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
 * THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * \asf_license_stop
 *
 */
/*
 * Support and FAQ: visit <a href="https://www.microchip.com/support/">Microchip Support</a>
 */
#include <asf.h>
#include <stdio.h>
#include "application.h"
#include "serial_interface.h"
#include "public.h"
#include "banner.h"
#include "settings.h"
#include "power_supply.h"




/* Functions and variables involving the term ps or power supply refers to the power supply boards where voltage 0-2500 v is specified and put out */
/* Functions and variables involving the terms pulse, firing, relay refer to the pulsing boards where the user will specify pulsing parameters such as
	on/off time, channel, cycle count, channel, schedule, etc */
/*  */


void usart_read_callback(struct usart_module *const usart_module);
void usart_write_callback(struct usart_module *const usart_module);

void relay_read_callback(struct usart_module *const relay_module);
void relay_write_callback(struct usart_module *const relay_module);


void configure_usart(void);
void configure_usart_callbacks(void);


volatile unsigned int event_flags;

//Application Structure
app_settings_t app_settings;

//Uart Structures
struct usart_module lantronix_instance;
struct usart_module *lantronix_instance_p = &lantronix_instance;

struct usart_config config_lantronix;
struct usart_module ps_instance;
struct usart_config config_ps;
struct usart_module relay_instance;
struct usart_config config_relay;

//Communication Buffers
volatile uint8_t lantronix_rx_buffer[1];
volatile uint8_t lantronix_command_buffer_idx;
volatile uint8_t lantronix_command_buffer[COMMAND_BUFFER_LENGTH];

volatile uint8_t ps_rx_buffer[1];
volatile uint8_t ps_response_buffer[COMMAND_BUFFER_LENGTH];
volatile uint8_t ps_rx_buffer_idx = 0;

volatile uint8_t relay_rx_buffer[1];
volatile uint8_t relay_response_buffer[COMMAND_BUFFER_LENGTH];
volatile uint8_t relay_rx_buffer_idx = 0;

/* USART Read callback for Comms between user and control board */
void usart_read_callback(struct usart_module *const usart_module)
{
	printf("%c",lantronix_rx_buffer[0]);
	if (lantronix_rx_buffer[0] == VT_LF)
	{
		return;
	}else if (lantronix_rx_buffer[0] == VT_FF){
		event_flags |= (1<<EF_VT_COMMAND);
	}else if (lantronix_rx_buffer[0] == VT_BS){
		if (lantronix_command_buffer_idx>0)
		{
			lantronix_command_buffer[--lantronix_command_buffer_idx] = 0;
			printf("%c%c",VT_SP,VT_BS);
		}
	}else if (lantronix_rx_buffer[0] == VT_CR){
		event_flags |= (1<<EF_UART_COMMAND);
		printf("\r\n");
		return;
	}else if ((event_flags & (1<<EF_UART_COMMAND)) == 0){
		lantronix_command_buffer[lantronix_command_buffer_idx++] = lantronix_rx_buffer[0];
	}else if (lantronix_command_buffer_idx >= COMMAND_BUFFER_LENGTH){
		lantronix_command_buffer_idx = 0;
	}else{
		return;
	}
		
}

/* USART Read callback for power supply */ 
void ps_read_callback(struct usart_module *const usart_module)
{
	if(ps_rx_buffer[0] == VT_LF) {
		//return;
	}else if (ps_rx_buffer[0] == VT_CR) {
		event_flags |= (1<<EF_PS_COMMAND);
		printf("\r\n");
		ps_response = VT_ACK;
		return;
	}else if ((event_flags & (1<<EF_PS_COMMAND)) == 0) {
		ps_response_buffer[ps_rx_buffer_idx++] = ps_rx_buffer[0];
		ps_response = VT_NAK;
		callback_count++;		
	} else {

		return;
	}
}

void ps_write_callback(struct usart_module *const ps_module)
{
	//Do Nothing Currently
	port_pin_toggle_output_level(LED_1_PIN);
}

/* USART Read callback for switching/relay/pulse board */ 
void relay_read_callback(struct usart_module *const relay_module)
{
	if(relay_rx_buffer[0] == VT_LF) {
		//return;
		}else if (relay_rx_buffer[0] == VT_CR) {
			event_flags |= (1<<EF_RELAY_COMMAND);
			printf("\r\n");
			f_response = VT_ACK;
			return;
		}else if ((event_flags & (1<<EF_RELAY_COMMAND)) == 0) {
			relay_response_buffer[relay_rx_buffer_idx++] = relay_rx_buffer[0];
		} else {
			return;
	}
}

void relay_write_callback(struct usart_module *const relay_module)
{
	
}

void usart_write_callback(struct usart_module *const usart_module)
{
	port_pin_toggle_output_level(LED_0_PIN);
	
}


/* configures usart and sets up communication channels */
void configure_usart(void)
{
	//Lantronix setup
	struct usart_config config_usart;
	usart_get_config_defaults(&config_usart);

	config_usart.baudrate    = 9600;
	config_usart.mux_setting = LANTRONIX_USART_MUX_SETTINGS;
	config_usart.pinmux_pad0 = LANTRONIX_USART_PINMUX_PAD0;
	config_usart.pinmux_pad1 = LANTRONIX_USART_PINMUX_PAD1;
	config_usart.pinmux_pad2 = LANTRONIX_USART_PINMUX_PAD2;
	config_usart.pinmux_pad3 = LANTRONIX_USART_PINMUX_PAD3;
	
	while (usart_init(&lantronix_instance,
	LANTRONIX_USART_MODULE, &config_usart) != STATUS_OK) {
	}
	usart_enable(&lantronix_instance);
	stdio_serial_init(&lantronix_instance,LANTRONIX_USART_MODULE, &config_usart);	
	
	//Do it again for the Power Supply Communications Channel
	usart_get_config_defaults(&config_usart);
	config_usart.baudrate    = 9600;
	config_usart.mux_setting = PS_USART_MUX_SETTINGS;
	config_usart.pinmux_pad0 = PS_USART_PINMUX_PAD0;
	config_usart.pinmux_pad1 = PS_USART_PINMUX_PAD1;
	config_usart.pinmux_pad2 = PS_USART_PINMUX_PAD2;
	config_usart.pinmux_pad3 = PS_USART_PINMUX_PAD3;
	
	while (usart_init(&ps_instance,
	PS_USART_MODULE, &config_usart) != STATUS_OK) {
	}
	usart_enable(&ps_instance);

	
	
	//Do it again for the Firing Board Communications Channel
	usart_get_config_defaults(&config_usart);
	config_usart.baudrate    = 9600;
	config_usart.mux_setting = RELAY_USART_MUX_SETTINGS;
	config_usart.pinmux_pad0 = RELAY_USART_PINMUX_PAD0;
	config_usart.pinmux_pad1 = RELAY_USART_PINMUX_PAD1;
	config_usart.pinmux_pad2 = RELAY_USART_PINMUX_PAD2;
	config_usart.pinmux_pad3 = RELAY_USART_PINMUX_PAD3;
	while (usart_init(&relay_instance,
	RELAY_USART_MODULE, &config_usart) != STATUS_OK) {	
	}
	usart_enable(&relay_instance);
	
}

void configure_usart_callbacks(void)
{
	//Lantronix
	usart_register_callback(&lantronix_instance,
			usart_write_callback, USART_CALLBACK_BUFFER_TRANSMITTED);
	usart_register_callback(&lantronix_instance,
			usart_read_callback, USART_CALLBACK_BUFFER_RECEIVED);
	usart_enable_callback(&lantronix_instance, USART_CALLBACK_BUFFER_TRANSMITTED);
	usart_enable_callback(&lantronix_instance, USART_CALLBACK_BUFFER_RECEIVED);
	
	//Power Supply
	usart_register_callback(&ps_instance,
			ps_write_callback, USART_CALLBACK_BUFFER_TRANSMITTED);
	usart_register_callback(&ps_instance,
			ps_read_callback, USART_CALLBACK_BUFFER_RECEIVED);
	usart_enable_callback(&ps_instance, USART_CALLBACK_BUFFER_TRANSMITTED);
	usart_enable_callback(&ps_instance, USART_CALLBACK_BUFFER_RECEIVED);
	
	//Firing Boards
	usart_register_callback(&relay_instance,
		relay_write_callback, USART_CALLBACK_BUFFER_TRANSMITTED);
	usart_register_callback(&relay_instance,
		relay_read_callback, USART_CALLBACK_BUFFER_RECEIVED);
	usart_enable_callback(&relay_instance, USART_CALLBACK_BUFFER_TRANSMITTED);
	usart_enable_callback(&relay_instance, USART_CALLBACK_BUFFER_RECEIVED);
	
	
}

void clear_command_buffer( void )
{
	//Clear command buffer
	unsigned char c = 0;
	for (c=0;c<COMMAND_BUFFER_SIZE;c++)
	{
		lantronix_command_buffer[c] = 0;
	}
	lantronix_command_buffer_idx = 0;
	
}
/* Handles events to know when to enter into serial interface */
static void handle_events( void )
{
	unsigned char c = 0;
	if (event_flags & (1<<EF_UART_COMMAND))
	{
		si_command(lantronix_command_buffer);
		event_flags &= ~(1<<EF_UART_COMMAND);

		lantronix_rx_buffer[0] = 0;
		for (c=0;c<COMMAND_BUFFER_LENGTH;c++)
			lantronix_command_buffer[c] = 0;
	
		lantronix_command_buffer_idx = 0;
		//printf("My Command Buffer is: '%s'\r\n",lantronix_command_buffer);

	}else if (event_flags & (1<<EF_VT_COMMAND)){
		VT_CLEAR_SCREEN;
		printf("Gate Keeper Debug Port\r\n\r\n>");
		lantronix_command_buffer_idx = 0;

		//Clear the buffer	
		memset_volatile(&lantronix_command_buffer,0,sizeof(lantronix_command_buffer));
		event_flags &= ~(1<<EF_VT_COMMAND);
	}else if (event_flags & (1<<EF_PS_COMMAND)){
		si_command(ps_response_buffer);
		ps_rx_buffer_idx = 0;
		memset_volatile(&ps_response_buffer,0,sizeof(ps_response_buffer));
		event_flags &= ~(1<<EF_PS_COMMAND);
		
	}else if (event_flags & (1<<EF_RELAY_COMMAND)){
		si_command(relay_response_buffer);
		relay_rx_buffer_idx = 0;
		memset_volatile(&relay_response_buffer,0,sizeof(relay_response_buffer));
		event_flags &= ~(1<<EF_RELAY_COMMAND);
	
}
	
}

static void get_application_settings( void )
{
	uint8_t page_data[EEPROM_PAGE_SIZE];
	eeprom_emulator_read_page(0, page_data);
	
	app_settings.frequency = (page_data[0] << 8) | page_data[1];
	
	if ((app_settings.frequency < 90000) || (app_settings.frequency > 110000))
	{
		app_settings.frequency = 100000;
	}
	
	
	app_settings.period = 1000000*46.6/app_settings.frequency;
	app_settings.match = app_settings.period / 2;
		
	// 	app_settings.dead_high = 81;
	// 	app_settings.dead_low = 81;
	// 	app_settings.period = 1000000*46.6/25000;
	// 	app_settings.match = app_settings.period / 2;
	// 	app_settings.frequency = 25000;
}

int main(void)
{
	system_init();

	get_application_settings();
	
	configure_usart();
	configure_usart_callbacks();

	system_interrupt_enable_global();
	clear_command_buffer();
	
	dsu_crc32_init();
	
	event_flags = 0;

 	uint32_t clock_rate = 0;
 	clock_rate = system_gclk_gen_get_hz(GCLK_GENERATOR_0);
 

	//printf("The Current Clock Rate is %lu Hz\r\n>",clock_rate);
	printf("GATEKEEPER V1.0.0\r\n");
	
// 	while(1)
// 	{
// 		for (u=0;u<2000000;u++)
// 		;
// 		TX_HIGH;
// 		for (u=0;u<2000000;u++)
// 		;
// 		
// 		TX_LOW;
// 		
// 		
// 	}
// 	while(1) {
// // 			enum status_code usart_write_wait(
// // 			struct usart_module *const module,
// // 			const uint16_t tx_data);
// // 			usart_write_wait(&ps_instance, 0x41);
// // 			usart_read_buffer_job(&ps_instance,
// // 			(uint8_t *)ps_rx_buffer, MAX_RX_BUFFER_LENGTH);
// 			//printf(ps_rx_buffer);
// 			//usart_write_wait(&lantronix_instance, (uint8_t *)lantronix_rx_buffer);
// 	}
	while (1) {
		
		
		handle_events();
		usart_read_buffer_job(&lantronix_instance,
				(uint8_t *)lantronix_rx_buffer, MAX_RX_BUFFER_LENGTH);
		usart_read_buffer_job(&ps_instance,
				(uint8_t *)ps_rx_buffer, MAX_RX_BUFFER_LENGTH);
		usart_read_buffer_job(&relay_instance,
				(uint8_t *)relay_rx_buffer, MAX_RX_BUFFER_LENGTH);

// 		settings_usart_destination(Power_Supply);
// 		for(int i = 0; i< 10000;i++);
// 		printf("wtf\r\n");
		
		}
	
}

