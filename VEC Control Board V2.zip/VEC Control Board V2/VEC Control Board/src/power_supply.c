/*
 * power_supply.c
 *
 * Created: 8/26/2022 1:56:55 PM
 *  Author: st991970
 */ 

#include <asf.h>
#include <string.h>
#include "power_supply.h"
#include "application.h"
#include "settings.h"
#include "my_tc.h"
#include "crc.h"

/*
Communications Protocol
[Packet Type] [Packet Length] [Packet Data] [16-bit checksum]
*/

power_supply_data_t	ps_data;
packet_t my_p;
uint8_t ps_response = 0;
uint8_t ps_comm_flags = 0;
uint8_t ps_buffer[PS_MAX_DATA_LENGTH];
uint8_t wait = 0;
fire_data_t	f_data;
uint8_t f_response = 0;
uint8_t f_comm_flags = 0;
uint8_t f_buffer[F_MAX_DATA_LENGTH];

struct usart_module ps_instance;
struct usart_config config_ps;
struct usart_module relay_instance;
struct usart_config config_relay;
struct tc_module ps_responseinst;

volatile uint8_t ps_rx_buffer[1];
volatile uint8_t relay_rx_buffer[1];

//volatile uint8_t callback_count = 0;

/* Comms flags for commands sent to power supply board */
static void ps_setup_communication_flags( void )
{
	Tc *my_timer = TC3;
	my_timer->COUNT32.COUNT.reg = 0;
	callback_count = 0;
	ps_response = 0;
	ps_comm_flags = 0;
	wait = 0;
}

/* Comms flags for commands sent to the switching board */
static void f_setup_communication_flags( void )
{
	Tc *my_timer = TC3;
	my_timer->COUNT32.COUNT.reg = 0;
	callback_count = 0;
	f_response = 0;
	f_comm_flags = 0;
	wait = 0;
}

static void ps_build_packet( uint8_t command, uint8_t *data, uint8_t data_length, short checksum )
{	
	unsigned char c = 0;
	
	my_p.command = command;
	my_p.length = data_length;
	my_p.data = data;
	
	//Clear the buffer
	memset(ps_buffer,0,sizeof(ps_buffer));
	
	ps_buffer[0] = command;
	ps_buffer[1] = data_length;
	for (c=0;c<data_length;c++)
	{
		ps_buffer[c+2] = *data++;		
	}
	//Total packet length is data + 2
	
	my_p.crc = get_crc(data_length+2,ps_buffer);
	ps_buffer[data_length+2] = ((my_p.crc & 0xFF00) >> 8);
	ps_buffer[data_length+3] = (my_p.crc & 0x00FF);
}

static void ps_send_packet( void )
{	
	uint8_t crc_hi = my_p.crc & 0xFF00 >> 16;
	uint8_t crc_lo = my_p.crc & 0x00FF;
	
	char buf[PS_MAX_DATA_LENGTH];
	
	sprintf(buf,"%c%c%s%c%c\r\n",my_p.command,my_p.length,my_p.data,crc_hi,crc_lo);
	settings_usart_destination(Power_Supply);
	printf("%s",buf);
}

static uint8_t ps_validate_packet( packet_t p )
{
	//Assume Success
	uint8_t retval = 0;
	
	
	//Check the first byte corresponds to a valid packet type
	if (!(p.command>=Command && p.command<=None))
	{
		retval |= (1<<0);
	}
	
	//Check the packet length
	if (p.length > PS_MAX_DATA_LENGTH)
	{
		retval |= (1<<1);
	}
	
	//Check CRC
	short my_crc = get_crc(p.length, p.data);
	if (!(my_crc == p.crc))
	{
		retval |= (1<<2);
	}
	
	return retval;
}

void ps_decode_packet( uint8_t *packet_data )
{
	uint8_t byte_count = 0;
	uint8_t data[16];
	uint8_t c = 0;
	uint16_t chksum = 0;
	
	if (packet_data[0] == Response_String)
	{
		//Well, this was as expected
		byte_count = packet_data[1];
		
		if (byte_count > 0)
		{
			for (c=2;c<(2+byte_count);c++)
			{
				data[c-2] = packet_data[c];
			}
			
		}else{
			//Zero length packet
		}
	}else if (packet_data[0] == Response_ACK){
		//Acknowledgment
		//[Ack][0][CHKLO][CHKHI]
		if (packet_data[1] == 0)
		{
			chksum = packet_data[2] + (packet_data[3] << 8);
			//todo validate checksum
			if (1)
			{
				//Checksum matches
				ps_comm_flags |= (1<<PS_FLAG_ACK);
			}else{
				ps_comm_flags |= (1<<PS_FLAG_INVALID);
			}
		}
		
	}else if (packet_data[0] == Response_NAK){
		//Negative Acknowledgment
		if (packet_data[1] == 0)
		{
			chksum = packet_data[2] + (packet_data[3] << 8);
			//Todo Validate Checksum
			if (1)
			{
				//Checksum matches
				ps_comm_flags |= (1<<PS_FLAG_NAK);
			}else{
				ps_comm_flags |= (1<<PS_FLAG_INVALID);
			}
			
		}
	}
}

/* Setup for a communications test command sent to power supply board */ 
comm_return_code_t ps_test(void)
{
	//long u = 0;
	settings_usart_destination(Power_Supply);
	ps_setup_communication_flags();
	
	printf("TEST\r\n");
	
	while (!(ps_response) && !(TIMER_EXPIRED_250))
	{
		
		usart_read_buffer_job(&ps_instance,
		(uint8_t *)ps_rx_buffer, MAX_RX_BUFFER_LENGTH);
		
		if (ps_rx_buffer[0] == 0) {
			callback_count++;
		}
	}

	/*for(int i = 0; i < 500; i++);*/
	settings_usart_destination(Lantronix);
	//printf("%.*s\r\n", sizeof(ps_response_buffer), ps_response_buffer);
	if(ps_response)
	{
		if(ps_response_buffer[0] == VT_ACK)
		{
			//Command was accepted
			return Ack;
			}else if(ps_response_buffer[0] == VT_NAK){
			//Command was not accepted
			return Nak;
			}else{
			//Not good maybe comms error?
			return Non_standard;
		}
		}else{
		//No response returned
		printf(" ERROR - TIMEOUT\r\n");
		return Timeout;
	}
}

/* Setup for a communications test command sent to firing/switching board */ 
comm_return_code_t f_test(void)
{
	//long u = 0;
	settings_usart_destination(Relay);
	f_setup_communication_flags();
	
		printf("FTEST\r\n");
	
	while (!(f_response) && !(TIMER_EXPIRED_250))
	{
		
		usart_read_buffer_job(&relay_instance,
		(uint8_t *)relay_rx_buffer, MAX_RX_BUFFER_LENGTH);
		
		if (relay_rx_buffer[0] == 0) {
			callback_count++;
		}
	}

	/*for(int i = 0; i < 500; i++);*/
	settings_usart_destination(Lantronix);
	//printf("%.*s\r\n", sizeof(relay_response_buffer), relay_response_buffer);
	if(f_response)
	{
		if(relay_response_buffer[0] == VT_ACK)
		{
			//Command was accepted
			return Ack;
			}else if(relay_response_buffer[0] == VT_NAK){
			//Command was not accepted
			return Nak;
			}else{
			//Not good maybe comms error?
			return Non_standard;
		}
		}else{
		//No response returned
		printf(" ERROR - TIMEOUT\r\n");
		return Timeout;
	}
}

/* Setup for a command to change duty cycle on the power supply board */
comm_return_code_t duty_set(float P)
{
	uint8_t Perc = 0;
	Perc = 1 * P;
	settings_usart_destination(Power_Supply);
	ps_setup_communication_flags();
	
	printf("DUTY %u\r\n", Perc);
	
	while (!(ps_response) && !(TIMER_EXPIRED_250))
	{
		
		usart_read_buffer_job(&ps_instance,
		(uint8_t *)ps_rx_buffer, MAX_RX_BUFFER_LENGTH);
		
		if (ps_rx_buffer[0] == 0) {
			callback_count++;
		}
	}

	/*for(int i = 0; i < 500; i++);*/
	settings_usart_destination(Lantronix);
	//printf("%.*s\r\n", sizeof(ps_response_buffer), ps_response_buffer);
	if(ps_response)
	{
		if(ps_response_buffer[0] == VT_ACK)
		{
			//Command was accepted
			return Ack;
			}else if(ps_response_buffer[0] == VT_NAK){
			//Command was not accepted
			return Nak;
			}else{
			//Not good maybe comms error?
			return Non_standard;
		}
		}else{
		//No response returned
		printf(" ERROR - TIMEOUT\r\n");
		return Timeout;
	}
}

/* Function for sending pulsing parameters to firing board */
comm_return_code_t ps_pulse(uint32_t chst, uint32_t chnxt, uint32_t chend, uint32_t plscnt, uint32_t cclrpts, uint32_t duty_h, uint32_t duty_l, uint32_t pausdur)
{
// 	uint32_t chanst = chst*1;
// 	uint32_t chnext = chnxt*1;
// 	uint32_t chanend = chend*1;
// 	uint32_t pulscnt = plscnt*1;
// 	uint32_t repts = cclrpts*1;
// 	uint32_t dut_h = duty_h * 1;
// 	uint32_t dut_l = duty_l * 1;
// 	uint32_t pausetime = pausdur * 1;
	
	settings_usart_destination(Relay);
	f_setup_communication_flags();
	int boardnum = 0;
	printf("PLS  %lu %lu %lu %lu %lu %lu %lu %lu %u\r\n", chst, chnxt, chend, plscnt, cclrpts, duty_h, duty_l, pausdur, boardnum);
	
	while (!(f_response) && !(TIMER_EXPIRED_1000))
	{
		//callback_count++;
		usart_read_buffer_job(&relay_instance,
		(uint8_t *)relay_rx_buffer, MAX_RX_BUFFER_LENGTH);
		
		if (relay_rx_buffer[0] == 0) {
			callback_count++;
		}
	}

	/*for(int i = 0; i < 500; i++);*/
	settings_usart_destination(Lantronix);
	//printf("%.*s\r\n", sizeof(ps_response_buffer), ps_response_buffer);
	if(f_response)
	{
		if(relay_response_buffer[0] == VT_ACK)
		{
			//Command was accepted
			return Ack;
			}else if(relay_response_buffer[0] == VT_NAK){
			//Command was not accepted
			return Nak;
			}else{
			//Not good maybe comms error?
			return Non_standard;
		}
		}else{
		//No response returned
		printf(" ERROR - TIMEOUT\r\n");
		return Timeout;
	}
}

/* Terminates previously specified pulsing */ 
comm_return_code_t ps_pulse_stop(void)
{
	
	settings_usart_destination(Relay);
	f_setup_communication_flags();
	
	printf("PULSE STOP\r\n");
	
	while (!(f_response) && !(TIMER_EXPIRED_250))
	{
		
		usart_read_buffer_job(&relay_instance,
		(uint8_t *)relay_rx_buffer, MAX_RX_BUFFER_LENGTH);
		
		if (relay_rx_buffer[0] == 0) {
			callback_count++;
		}
	}

	/*for(int i = 0; i < 500; i++);*/
	settings_usart_destination(Lantronix);
	//printf("%.*s\r\n", sizeof(ps_response_buffer), ps_response_buffer);
	if(f_response)
	{
		if(relay_response_buffer[0] == VT_ACK)
		{
			//Command was accepted
			return Ack;
			}else if(relay_response_buffer[0] == VT_NAK){
			//Command was not accepted
			return Nak;
			}else{
			//Not good maybe comms error?
			return Non_standard;
		}
		}else{
		//No response returned
		printf(" ERROR - TIMEOUT\r\n");
		return Timeout;
	}
}

/* Setup for a command that sets specified KV value for the power supply */
comm_return_code_t ps_set_kv(float f)
{
	uint16_t ps;
	settings_usart_destination(Power_Supply);
	ps_setup_communication_flags();
// 	short my_crc = get_crc(0,NULL);
// 	
// 	ps_build_packet(Command,NULL,0,my_crc);
// 	ps_send_packet();
	ps = f * 1000;
	printf("SET %u\r\n", ps);
	
	while (!(ps_response) || (TIMER_EXPIRED_250))
	{
		
		usart_read_buffer_job(&ps_instance,
		(uint8_t *)ps_rx_buffer, MAX_RX_BUFFER_LENGTH);
		
		if (ps_rx_buffer[0] == 0) {
			callback_count++;
		}
	}
	
	settings_usart_destination(Lantronix);
	//printf("%.*s\r\n", sizeof(ps_response_buffer), ps_response_buffer);
	if(ps_response)
	{
		if(ps_response_buffer[0] == VT_ACK)
		{
			//Command was accepted
			return Ack;
		}else if(ps_response_buffer[0] == VT_NAK){
			//Command was not accepted
			return Nak;
		}else{
			//Not good maybe comms error?
			return Non_standard;
		}
	}else{
		//No response returned
		printf(" ERROR - TIMEOUT\r\n");
		return Timeout;
	}
}

/* Power supply command for activating and deactivating the mains relay */
comm_return_code_t ps_mains(uint8_t off_on)
{
	settings_usart_destination(Power_Supply);
	/*for(int i = 0; i < 500; i++){*/
	printf("MAINS %u\r\n",off_on);
	ps_setup_communication_flags();
	
	while (!(ps_response) && !(TIMER_EXPIRED_250))
	{
		
		//
		
		
		usart_read_buffer_job(&ps_instance,
		(uint8_t *)ps_rx_buffer, MAX_RX_BUFFER_LENGTH);
		if (ps_rx_buffer[0] == 0) {
			callback_count++;
		}
		
	}
	
	
	
	settings_usart_destination(Lantronix);
	if(ps_response)
	{
		if(ps_response_buffer[0] == VT_ACK)
		{
			//Command was accepted
			return Ack;
		}else if(ps_response_buffer[0] == VT_NAK){
			//Command was not accepted
			return Nak;
		}else{
			//Not good maybe comms error?
			return Non_standard;
		}
	}else{
		//No response returned
		printf(" ERROR - TIMEOUT\r\n");
		return Timeout;
		
	}
}

comm_return_code_t ps_bus_discharge(uint8_t off_on)
{
	settings_usart_destination(Power_Supply);
	printf("DRAIN_BUS\r\n");
	
	ps_setup_communication_flags();
	
	while(!(ps_response) || (TIMER_EXPIRED_250))
	;
	
	settings_usart_destination(Lantronix);
	
	if (ps_response)
	{
		if ((!ps_response_buffer[0]) == 0)
		{
			return Timeout;
		}else if(ps_response_buffer[0] == VT_ACK){
			return Ack;
		}else if(ps_response_buffer[0] == VT_NAK){
			return Nak;
		}else{
			return Non_standard;
		}
	}else{
		//No response returned
		return Timeout;
	}
}

/* Command for requesting Kv value from power supply */
comm_return_code_t ps_get_bus_voltage( float f )
{	
	settings_usart_destination(Power_Supply);
	
	//printf("BUS?\r\n");

	//ps_build_packet(Command,NULL,0,)

	ps_setup_communication_flags();
		
	while(!(ps_response) || (TIMER_EXPIRED_250))
	;
	settings_usart_destination(Lantronix);
		
	if (ps_response)
	{
		if (ps_response_buffer[0] == Response_Float)
		{
			
		}
		
	}else{
		//No response returned
		return Timeout;
	}
	
	if (ps_response_buffer[0] == 0)
	{
		return Timeout;
	}else if(ps_response_buffer[0] == VT_NAK){
		return Nak;
	}
		
		
		
		
		
			if(ps_response)
			{
				if(ps_response_buffer[0] == VT_ACK)
				{
					//Command was accepted
					return Ack;
					}else if(ps_response_buffer[0] == VT_NAK){
					//Command was not accepted
					return Nak;
					}else{
					//Not good maybe comms error?
					return Non_standard;
				}
				}else{
				//No response returned
				return Timeout;
				
			}
		
		
		
		
		
		
		
}

/* Command for requesting Kv value from power supply */
float ps_get_high_side_voltage(void)
{
	settings_usart_destination(Power_Supply);
	
	printf("HBUS?\r\n");

	ps_setup_communication_flags();	
	while(!(ps_response) && !(TIMER_EXPIRED_250))
	{
		
	usart_read_buffer_job(&ps_instance,
	(uint8_t *)ps_rx_buffer, MAX_RX_BUFFER_LENGTH);
	
	}
	settings_usart_destination(Lantronix);
	
	if(ps_response)
	{
		if(ps_response_buffer[0] == VT_ACK)
		{
			//Command was accepted
			return Ack;
			}else if(ps_response_buffer[0] == VT_NAK){
			//Command was not accepted
			return Nak;
			}else{
			//Not good maybe comms error?
			return Non_standard;
		}
		}else{
		//No response returned
		return Timeout;
// 	if (ps_response)
// 	{
// 		printf("%f\r\n",ps_data.bus_voltage);
// 	}else{
// 		printf("CF\r\n");
// 	}
// 	settings_usart_destination(Lantronix);
// 	return 0;
	}
}

power_supply_status_t ps_get_hardware_status( void )
{
	power_supply_status_t s = Not_Ready;
	
	if (port_pin_get_input_level(PS_IN_SIG_1))
	{
		return s;	
	}
	
	//If code is running then it must be ready
	s = Ready;
	return s;
	
}

