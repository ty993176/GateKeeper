/*
 * public.c
 *
 * Created: 3/21/2022 3:01:10 PM
 *  Author: st991970
 */ 
#include <asf.h>
#include "public.h"

void memset_volatile(volatile void *s, char c, size_t n)
{
	volatile char *p = s;
	while (n-- > 0) {
		*p++ = c;
	}
}