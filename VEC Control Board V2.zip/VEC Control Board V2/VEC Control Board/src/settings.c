/*
 * settings.c
 *
 * Created: 8/23/2022 10:53:51 AM
 *  Author: st991970
 */ 

#include <asf.h>
#include "application.h"
#include "settings.h"


/* Function to specifity target board for usart. */ 
inline void settings_usart_destination( serial_device_t sd )
{
	if (sd == Lantronix)
	{
		stdio_serial_init(&lantronix_instance, LANTRONIX_USART_MODULE, &config_lantronix);
	}
	else if (sd == Power_Supply){
		stdio_serial_init(&ps_instance, PS_USART_MODULE, &config_ps);
	}
else if (sd == Relay){
		stdio_serial_init(&relay_instance, RELAY_USART_MODULE, &config_relay);
	}
}
